/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  Chương trình xử lý máy in.
  1st dev by @MrCong: thanhcong402@gmail.com
  *
  ******************************************************************************
  */

/**
 ******************************************************************************
  * @brief          : Todo
  ******************************************************************************
-in bill dài đang bị sai data gửi lên server: đang bị chồng data chỗ chuyển tiếp các gói in:
	nguyên nhân: đang dư 3 byte 00 00 00 khi gói 1 là 85 byte.

-so sánh bộ nhớ khi lưu vào
-hiện đang hỗ trợ in/lưu cùng lúc 2 file, lớn hơn thì vẫn in, nhưng ko lưu lại.
-lúc khởi động hay bị đứng: không nhận diện được máy in-->cần xử lý lại
-mở endpoint cho th có 2 interface

*/

/**
 ******************************************************************************
  * @brief          : Done
  ******************************************************************************
-chỉnh lại xử lý data để hỗ trợ in nhiều file liên tiếp.
-cập nhật thông tin máy in qua esp
-có data in thì phải dừng truyền qua esp-->không sẽ bị xung đột ghi/đọc file: fixed: truyền uart interupt
-kiểm tra lại xóa flash data printed
*/

/**
 ******************************************************************************
  * @brief          : Ghi chú coding
  ******************************************************************************




Các điểm mở endpoint

key: VirtualDeviceEndpoint	USBD_LL_OpenEP
key: VirtualHostEndpoint	USBH_OpenPipe


HAL_PCD_IRQHandler	: hàm xử lý ngắt USB
USB_OTG_GINTSTS_IEPINT	: In endpoint interupt
USB_OTG_GINTSTS_OEPINT	: Out endpoint interupt

USBH_LL_GetURBState	: Get a URB state from the low level driver.

flow:
	PC -> box		: control	:	usbd_core.c \ USBD_LL_SetupStage
					: data		:	USBD_LL_DataOutStage\USBD_CDC_DataOut\ CDC_Receive_HS
	box -> PC		:CDC_Transmit_HS.


	Box ->printer	:USBH_CDC_Transmit.
	printer->Box	:USBH_CDC_Receive.


Các hàm callback:

	PC -> box		:CDC_Receive_HS		(HAL_PCD_DataOutStageCallback\USBD_LL_DataOutStage \USBD_CDC_DataOut\DataOut\CDC_Receive_HS)
	box -> PC		:USBD_CDC_DataIn	(HAL_PCD_DataInStageCallback \ USBD_LL_DataInStage )



	Box ->printer	:USBH_CDC_TransmitCallback 	(usbh_cdc.c \ CDC_ProcessTransmission	: sau khi truyền và printer nhận thành công, sẽ xuất hiện hàm này. Nếu có lỗi: URB_Status == USBH_URB_NOTREADY
	printer->Box	:USBH_CDC_ReceiveCallback


FREERTOS CMSIS_V2: khi kết nối device vào: box sẽ bị treo-->chuyển sang xài FREERTOS CMSIS_V1


 */

/* USER CODE BEGIN Header */
/*	#if (MY_USB_DEV == 1U)

HAL_PCD_IRQHandler



chỉnh thông số này cho phù hợp
HAL_PCDEx_SetTxFiFo

khi truyền lên PC thành công sẽ gọi hàm sau:
USBD_CDC_DataIn

 CMD = 2  1  0  0  1  0  0  0		URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL [0x01] : UsbdPipeTypeBulk             PipeDirectionOut
 CMD = 2  1  0  0  82  0  0  0		URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL [0x82] : UsbdPipeTypeBulk             PipeDirectionIn
 CMD = 0 9 1 0 0 0 0 0				set config
 CMD = c1  0  0  0  0  0  2  0
 	URB_FUNCTION_VENDOR_INTERFACE
	bmRequestType:	INTERFACE, STANDART
	bRequest: 		get status

CMD = c1  1  0  0  0  0  2  0
	URB_FUNCTION_VENDOR_INTERFACE
	bmRequestType:	INTERFACE, STANDART
	bRequest: 		CLEAR_FEATURE
	wValue:			Feature	Selector

CMD = 41  2  0  0  0  0  0  0
	URB_FUNCTION_VENDOR_INTERFACE
	bmRequestType:	INTERFACE, STANDART
	bRequest: 		02

	OUT, SHORT_OK, DEFAULT_PIPE



URB_FUNCTION_SET_FEATURE_TO_ENDPOINT
khi gặp lệnh này: gói in sẽ bị lỗi: USBD_STATUS_STALL_PID
in ra sẽ bị rác

bmRequestType	02	ENDPOINT, STANDART
bRequest		03	SET_FEATURE
SET_FEATURE		00	Feature	Selector
wIndex			01

máy in gốc cũng bị lỗi: nhưng in ra vẫn bình thường



URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL

1. CLEAR_FEATURE request to clear the device's ENDPOINT_HALT feature
2. RESET PIPE
3.

USBH_LL_SetToggle


URB_FUNCTION_VENDOR_INTERFACE
CMD = 41  20  00  00  00  00  03  00

bmRequestType	41: INTERFACE, STANDART
bRequest		20

 */

/**
 Máy in Epson
 Model	: TM-T88IV
 PID	: 202h
 VID	: 4b8h
 SN		: L9LF018916

 PC Request data		Printer respone
 init:
 00 00 00 00		->	3b 31 00
 10 4 1 10 14 7 1	->	16
 10 4 3 0			->	12

 Select peripheral device
 1b 3d 1			->	zlp

 Transmission of Printer ID
 1d 49 1			->	20
 1d 49 43			->	5f 54 4d 2d 54 38 38 49 56 0
 1b 28 73 4 0 31 41 4e d3	-> 7b 20 41 34 45 35 33 34 38 34 37 34 32 34 35 34 36 34 37 0
 1d 49 71			-> 5f 31 0
 1d 49 70			-> 5f 30 0
 1d 49 45			-> 5f 0
 1d 61 ff			-> 14 0 0 f

 thông báo chuẩn bị in:
  1b 3d 1 1d 49 1	-> 20

 data printing...

 sau khi in xong: (1 trong các gói sau)






 1d 28 48 6 0 30 30 20 20 20 26		-> zlp
 1d 28 48 6 0 30 30 20 20 20 3c		-> zlp
 1d 28 48 6 0 30 30 20 20 20 4f		-> zlp


 1D 28 48 06 00 30 30 d1 d2 d3 d4

 4 giá trị cuối là  process ID



 Thông báo in xong lên PC:

16:06:24.331 -> #PRT: ----------inform BUSY----------------
16:06:24.331 -> cmd @42 43, len = 11, data:


1d 28 48 6 0 30 30 20 20 20 56



poll printer len = 7 : 37 22 20 20 20 4f 0
poll printer len = 7 : 37 22 20 20 20 52 0
poll printer len = 7 : 37 22 20 20 20 56 0


 */





/*
Khai báo 2 biến này =1 để dùng transfer
USBH_MRCONG_USETRANSFER
USBD_MRCONG_USETRANSFER

USBH_MRCONG_DEDUBG
USBD_MRCONG_DEDUBG

USBH_MAX_NUM_INTERFACES


HAL_PCD_IRQHandler	: hàm ngắt xử lý tín hiệu USB



USBD_LL_DataOutStage: đây là hàm nhận tất cả package từ PC truyền xuống BOX (en0, en data...)

USBD_cdc("723 ready rec = %d",req->wLength);: đây là chỗ CDC thiết lập nhận data khi mới mở cổng

Box nhận request từ PC: usbd_core.c \ USBD_LL_SetupStage


flow:
	PC -> box		:CDC_Receive_HS
						usbd_core.c \ USBD_LL_SetupStage 296		lệnh request từ PC truyền xuống box
						quản lý gửi package USBD_LL_DataOutStage 400

	Box ->printer	:USBH_CDC_Transmit
						usbh_ctlreq.c\USBH_guilenhtestquaprinter\USBH_CtlReq\USBH_HandleControl 815

	printer->Box	:USBH_CDC_Receive không đọc được zlp,

	box -> PC		:CDC_Transmit_HS, usbd_core.c \ USBD_LL_DataInStage

USBH_CDC_TransmitCallback
USBH_CDC_ReceiveCallback


USBD_CDC_ReceivePacket: hàm này thông báo sẵn sàng nhận data

USBH_InterruptReceiveData


 */


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "flash.h"
#include "usb_device.h"
#include "usb_host.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbh_cdc.h"
#include "usbd_ioreq.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
  CDC_STATE_IDLE = 0,
  CDC_SEND,
  CDC_RECEIVE,
}CDC_StateTypedef;

CDC_StateTypedef CDC_STATE = CDC_STATE_IDLE;

typedef enum {
  BOX_STATE_IDLE = 0,
  BOX_CMD_CONTROL,
  BOX_CMD_DATA,
  BOX_WAIT_DATA_FROM_PRINTER,
  BOX_PRINT_DATA,
  BOX_WAIT_PRINTING,
  BOX_WAIT_DELAY_PRINTING,
  BOX_GET_NEXT,
  BOX_CONTROL_TO_PC,
}BOX_StateTypedef;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PRINTER_BUFF_SIZE   200


#if (usingchip == chip1M)
	const char *VERSION_NAME =	"1.2.2"; /* không sử dụng biến này */
#else
	const char *VERSION_NAME =	"1.1.0";
#endif


/*


qui  định mới

hardware.printertype.release

qui định cũ:

hardware.firmware.release

#hardware
	=1: phiên bản có cổng USB, serial...không có ROM ngoài

#firmware
	=0:	firmware đầu tiên: dang demo bên Sing
	=1: chip STM32F205VET 256k
	=2: chip STM32F205VGT 1M



*/
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
extern USBH_HandleTypeDef hUsbHostFS;
extern ApplicationTypeDef Appli_state;
extern USBD_HandleTypeDef hUsbDeviceHS;
extern uint32_t             USBH_LL_GetLastXferSize(USBH_HandleTypeDef *phost,
                                             uint8_t pipe);

extern uint8_t CDC_Transmit_HS(uint8_t* Buf, uint16_t Len);

uint32_t ui32_counter_led=0;
uint32_t ui32_counter_send_status =0 ;
uint16_t len_rec =0U;
uint8_t ui8_indebug = 0U;
uint8_t  status_led =0U;

uint8_t PRINTER_RX_Buffer[PRINTER_BUFF_SIZE];
uint8_t PRINTER_TX_Buffer[2100];
uint8_t PRINTER_CTL_Buffer[PRINTER_BUFF_SIZE];
int len_tx_to_esp;

uint8_t ui8_printer_status =0;//default not ready
uint8_t thongbaoinxong = 0;
#define RX5_BUFF_SIZE   20

uint8_t USER_RX_Buffer[RX5_BUFF_SIZE];/* usart buffer*/
uint8_t USER_TX_Buffer[RX5_BUFF_SIZE];
uint8_t ui8_max_ep0_size		=	8U;
uint8_t ui8_enpoint_addressCOM	=	0x83U;
uint16_t ui16_maxSizeCOM		=	0x0AU;
uint8_t ui8_enpoint_addressIN	=	0x81U;
uint16_t ui16_maxSizeIN			=	0x40U;
uint8_t ui8_enpoint_addressOUT	=	0x02U;
uint16_t ui16_maxSizeOUT		=	0x40U;


//uint8_t request_Buffer[MAX_USER_GET_USB_REQUEST][50];


//MY_CMD_TypeDef request_manager[MAX_USER_GET_USB_REQUEST];

//uint8_t dataprint_Buffer[MAX_USER_GET_USB_DATA][64];

//uint8_t mydataprint_Buffer[MAX_USER_GET_USB_DATA][4096]; /* tràn pointer chỗ này?????????????????????????????*/
volatile uint8_t dataprint_doing = 0U;

uint8_t request_index=0;
uint8_t ui8_user_state=0;
uint8_t ui8_cmd_doiong=0;
uint8_t ui8_need_reinint =0U;
uint8_t ui8_commandprinter =0U;
uint8_t ui8_busy_state =0U;
uint16_t ui16_counter_sent_data_to_pc =0;
uint8_t  ui8_txstatustoprinter = 0U; /* =1  đã truyền và có phản hồi, =0 đang truyền */
uint8_t  kq_old =0U;
uint16_t  ui16_counterbusy=0U;
uint8_t ui8_timeout =0U;
uint8_t ui8_counter_tx_data =0U;
uint16_t ui16_counter_wait_printing =0U;
uint8_t ui8_test_state =0U;
uint32_t u32_addr_data_user =0U;
uint32_t ui32_package_index_total =0U;
uint16_t lentosend = 0U;
uint32_t ui32_time_delay_next_pring =0;

uint32_t ui32_total_data_print= 0U;
uint32_t ui32_package_index_sending= 0U;
uint32_t ui32_data_offset= 0U;
uint8_t ui8_finished_printer = 0U;
uint8_t ui8_package_tx =0U;
uint32_t ui32_txprinterlength =0U;
uint8_t ui8_status_esp =0U;
uint32_t ui32_timerxset =0;

USER_TypeDef user_manage_request;
USER_TypeDef *pcommand =&user_manage_request;
USER_cacbien_chung_TypeDef my_var_user;
USER_cacbien_chung2_TypeDef quanlytruyendata;
USER_cacbien_dungdebug_code_TypeDef biendebug_code;
USER_cacbien_truyenquaESP_TypeDef quanlyESP;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART5_Init(void);
void MX_USB_HOST_Process(void);

/* USER CODE BEGIN PFP */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar (int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc (int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
HAL_UART_Transmit(&huart1,(uint8_t *)&ch,1,0xFFFF);

return ch;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Định nghĩa hàm để khởi động lại
void System_Reboot(void)
{
    // Disable all interrupts
    __disable_irq();

    // Set the SYSRESETREQ bit in the Cortex-M NVIC Application Interrupt and Reset Control Register (AIRCR)
    // để yêu cầu reset hệ thống
    SCB->AIRCR = (0x5FA << SCB_AIRCR_VECTKEY_Pos) | (SCB_AIRCR_SYSRESETREQ_Msk);

    // Vòng lặp vô hạn để chờ cho đến khi reset
    while (1) { }
}


void inmainstatus()
{
	if ( HAL_GetTick() > ui32_counter_led )
	{

		if (status_led == 1U) {
			status_led =0;
			HAL_GPIO_WritePin(LedSys_GPIO_Port,LedSys_Pin,1);
			if(ui8_finished_printer == 1U)
			{
				ui32_counter_led=HAL_GetTick() + 100;
			}
			else
			{
				if(ui8_printer_status ==1U)
				{
					ui32_counter_led=HAL_GetTick() + 50;
				}
				else
				{
					ui32_counter_led=HAL_GetTick() + 500;
				}
			}
		}
		else
		{
			status_led =1;
			HAL_GPIO_WritePin(LedSys_GPIO_Port,LedSys_Pin,0);
			if(ui8_finished_printer ==1U )
			{
				ui32_counter_led=HAL_GetTick() + 100;
			}
			else
			{
				if(ui8_printer_status ==1U)
				{
					ui32_counter_led=HAL_GetTick() + 950;
				}
				else
				{
					ui32_counter_led=HAL_GetTick() + 500;
				}
			}
		}

//		HAL_GPIO_TogglePin(LedSys_GPIO_Port,LedSys_Pin);
	}
}

void send_satatus()
{
	//
	if(ui8_finished_printer ==1U )
	{
		ui32_counter_send_status=HAL_GetTick() + 25000;
		return;
	}

	if ( HAL_GetTick() > ui32_counter_send_status )
	{
		ui32_counter_send_status=HAL_GetTick() + 25000;
//		SERIAL_TO_SERVER("CMD I%d %s", ui8_printer_status,VERSION_NAME);
		SERIAL_TO_SERVER("CMD I%d %d.%d.%d", ui8_printer_status,HWVERSION,PRINTER_MODEL,RELEASEVS);
	}
}
#if (0)
void test_tx_it()
{
	  uint32_t tam = HAL_GetTick();

	  if(tam > biendebug_code.u32_timeout)
	  {
		  uint8_t k ='a';
		  for(int m =0;m<24;m++)
		  {
			  quanlyESP.datatosend[m] = k;
			  k++;
		  }
		  quanlyESP.status_tx_datruyenxong =0;
		  int len = sprintf ((char *)PRINTER_TX_Buffer, "CMD I0 0.0.0 %d 0123456789_0123456789_0123456789_0123456789_0123456789_0123456789\n", biendebug_code.counter);
		  HAL_StatusTypeDef tt = HAL_UART_Transmit_IT(&huart1,PRINTER_TX_Buffer,len);
		  biendebug_code.u32_meas = HAL_GetTick();
		  HAL_GPIO_TogglePin(GPIOD,GPIO_PIN_14);
		  biendebug_code.u32_timeout = tam + 5000;
	  }

	  if (quanlyESP.status_tx_datruyenxong == 1)
	  {
		  uint32_t tam1 = HAL_GetTick() - biendebug_code.u32_meas;
		  quanlyESP.status_tx_datruyenxong =0;
		  USBH_UsrLog("\n #tx finish = %d time = %ld ms",biendebug_code.counter,tam1);
		  biendebug_code.counter++;
	  }
}
#endif

void check_snifff()
{
	if(pcommand->chophepsniff !=2U) return;
	// kiểm tra điều kiện dừng tự động: timeout / đủ kích thước qui định....

	if (pcommand->readytopausesniff ==1U)
	{
		//kiểm tra thời gian sau 5S dừng lại
		if (HAL_GetTick() > pcommand->timer_pausesniff + 10000)
		{
			USBH_UsrLog("auto end sniff");
			pcommand->readytopausesniff =0U;
			pcommand->chophepsniff =0U;
			pcommand->ui8_startprint =0U;
			pcommand->ui8_printing =0U;
			pcommand->WAIT_SEND_TO_SERVER =1U;
			pcommand->number_printed++;

			uint32_t diachitam = pcommand->u32_addr_header_store;
			//chỉ có 1 gói duy nhất
			pcommand->package_index =1;

			/* save total package */
			 Flash_Write_Data(diachitam, &pcommand->package_index, 1U);

			 USBD_UsrLogCog(" total package = %d \n", pcommand->package_index);

			 diachitam+=4;
			 /* save len package */
			Flash_Write_Data(diachitam, &pcommand->data_print_size, 1U);
		}
	}
}

//uint8_t i=0;

void user_init_values()
{
	user_manage_request.duocphepdebug =DEBUG_OK;

	my_var_user.ui8_user_forward_state =BOX_STATE_IDLE;
	my_var_user.ui8_chophep_docdata_tu_realdevice =0U;
	my_var_user.ui8_need_reinint_Virtual_Device =0U;
	user_manage_request.request_dang_thuc_thi =0U;
	user_manage_request.request_tong_nhan =0U;
}

void printinfoDevice()
{
	uint8_t tam;
	uint8_t interface;

	USBD_UsrLog("\n-------------Device information------------------------------------------.");
	USBD_UsrLog("_DeviceDescriptor.");//Middlewares\ST\STM32_USB_Host_Library\Core\Inc\usbh_core.h
	USBH_UsrLog("bLength: %xh", hUsbHostFS.device.DevDesc.bLength);
	USBH_UsrLog("bDescriptorType: %xh", hUsbHostFS.device.DevDesc.bDescriptorType);
	USBH_UsrLog("bcdUSB: %xh", hUsbHostFS.device.DevDesc.bcdUSB);
	USBH_UsrLog("bDeviceClass: %xh", hUsbHostFS.device.DevDesc.bDeviceClass);
	USBH_UsrLog("bDeviceSubClass: %xh", hUsbHostFS.device.DevDesc.bDeviceSubClass);
	USBH_UsrLog("bDeviceProtocol: %xh", hUsbHostFS.device.DevDesc.bDeviceProtocol);
	USBH_UsrLog("bMaxPacketSize: %xh", hUsbHostFS.device.DevDesc.bMaxPacketSize);
	USBH_UsrLog("idVendor: %xh", hUsbHostFS.device.DevDesc.idVendor);
	USBH_UsrLog("idProduct: %xh", hUsbHostFS.device.DevDesc.idProduct);
	USBH_UsrLog("bcdDevice: %xh", hUsbHostFS.device.DevDesc.bcdDevice);
	USBH_UsrLog("iManufacturer: %xh", hUsbHostFS.device.DevDesc.iManufacturer);
	USBH_UsrLog("iProduct: %xh", hUsbHostFS.device.DevDesc.iProduct);
	USBH_UsrLog("iSerialNumber: %xh", hUsbHostFS.device.DevDesc.iSerialNumber);
	USBH_UsrLog("bNumConfigurations: %xh", hUsbHostFS.device.DevDesc.bNumConfigurations);

	USBD_UsrLog("\n----------------ConfigurationDescriptor---------------------------------------.");
	USBH_UsrLog("bLength: %xh", hUsbHostFS.device.CfgDesc.bLength);
	USBH_UsrLog("bDescriptorType: %xh", hUsbHostFS.device.CfgDesc.bDescriptorType);
	USBH_UsrLog("wTotalLength: %xh", hUsbHostFS.device.CfgDesc.wTotalLength);
	USBH_UsrLog("bNumInterfaces: %xh", hUsbHostFS.device.CfgDesc.bNumInterfaces);
	USBH_UsrLog("bConfigurationValue: %xh", hUsbHostFS.device.CfgDesc.bConfigurationValue);
	USBH_UsrLog("iConfiguration: %xh", hUsbHostFS.device.CfgDesc.iConfiguration);
	USBH_UsrLog("bmAttributes: %xh", hUsbHostFS.device.CfgDesc.bmAttributes);
	USBH_UsrLog("bMaxPower: %xh", hUsbHostFS.device.CfgDesc.bMaxPower);


	USBD_UsrLog("\n------------------InterfaceDescriptor-------------------------------------.");

	interface=0;
	USBD_UsrLog("\n---@interface 1--");

	USBH_UsrLog("bLength             : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bLength);
	USBH_UsrLog("bDescriptorType     : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bDescriptorType);
	USBH_UsrLog("bInterfaceNumber    : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceNumber);
	USBH_UsrLog("bAlternateSetting   : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bAlternateSetting);
	USBH_UsrLog("bNumEndpoints       : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bNumEndpoints);
	USBH_UsrLog("bInterfaceClass     : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceClass);
	USBH_UsrLog("bInterfaceSubClass  : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceSubClass);
	USBH_UsrLog("bInterfaceProtocol  : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceProtocol);
	USBH_UsrLog("iInterface          : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].iInterface);

	interface = hUsbHostFS.device.CfgDesc.bNumInterfaces;
	if(interface > 1)
	{
		interface=1;
		USBD_UsrLog("\n\n---@interface 2--");
		USBH_UsrLog("bLength              : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bLength);
		USBH_UsrLog("bDescriptorType      : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bDescriptorType);
		USBH_UsrLog("bInterfaceNumber     : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceNumber);
		USBH_UsrLog("bAlternateSetting    : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bAlternateSetting);
		USBH_UsrLog("bNumEndpoints        : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bNumEndpoints);
		USBH_UsrLog("bInterfaceClass      : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceClass);
		USBH_UsrLog("bInterfaceSubClass   : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceSubClass);
		USBH_UsrLog("bInterfaceProtocol   : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bInterfaceProtocol);
		USBH_UsrLog("iInterface           : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].iInterface);
	}


	USBD_UsrLog("\n----------------EndpointDescriptor---------------------------------------.");


	interface=0;
	USBD_UsrLog("\n ---EndpointDescriptor for interface %d",(interface+1));

	int endpoint_have = hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bNumEndpoints;

	for (int ept=0; ept<endpoint_have;ept++)
		{
			USBD_UsrLog("\t -----endpoint @%d-------------",ept);

//			USBH_UsrLog("bLength            : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bLength);
//			USBH_UsrLog("bDescriptorType    : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bDescriptorType);
			USBH_UsrLog("bEndpointAddress   : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress);

			USBH_UsrLog("\tAddress : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress & 0x0F);
			if ((hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress) & (1U << 7))
			{
				USBH_UsrLog("\tDirection =Input");
			}
			else
			{
				USBH_UsrLog("\tDirection =Output");
			}

//			USBH_UsrLog("bmAttributes       : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bmAttributes);
			tam=hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bmAttributes;
			tam &= 0b00000011;
			if(tam   == 0b00000000)
			{
				USBH_UsrLog("\tType = Control");
			}
			else if(tam   == 0b00000001)
			{
				USBH_UsrLog("\tType = Isochronous");
			}
			else if(tam   == 0b00000010)
			{
				USBH_UsrLog("\tType = Bulk");
			}
			else if(tam   == 0b00000011)
			{
				USBH_UsrLog("\tType = Interrupt");
			}

			USBH_UsrLog("wMaxPacketSize     : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].wMaxPacketSize);
			USBH_UsrLog("bInterval          : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bInterval);
			USBH_UsrLog("\n");
		}

		interface = hUsbHostFS.device.CfgDesc.bNumInterfaces;
		if(interface > 1)
		{
			interface=1;
			USBD_UsrLog("\n ---EndpointDescriptor for interface %d",(interface+1));
			endpoint_have = hUsbHostFS.device.CfgDesc.Itf_Desc[interface].bNumEndpoints;

			for (int ept=0; ept<endpoint_have;ept++)
			{
				USBD_UsrLog("---------endpoint @%d-------------",ept);
				USBH_UsrLog("bLength            : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bLength);
				USBH_UsrLog("bDescriptorType    : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bDescriptorType);
				USBH_UsrLog("bEndpointAddress   : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress);

				USBH_UsrLog("\tAddress    : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress & 0x0F);
				if ((hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bEndpointAddress) & (1U << 7))
				{
					USBH_UsrLog("\tDirection =Input");
				}
				else
				{
					USBH_UsrLog("\tDirection =Output");
				}
//				USBH_UsrLog("bmAttributes       : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bmAttributes);
				tam=hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bmAttributes;
				tam &= 0b00000011;
				if(tam   == 0b00000000)
				{
					USBH_UsrLog("\tType = Control");
				}
				else if(tam   == 0b00000001)
				{
					USBH_UsrLog("\tType = Isochronous");
				}
				else if(tam   == 0b00000010)
				{
					USBH_UsrLog("\tType = Bulk");
				}
				else if(tam   == 0b00000011)
				{
					USBH_UsrLog("\tType = Interrupt");
				}

				USBH_UsrLog("wMaxPacketSize     : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].wMaxPacketSize);
				USBH_UsrLog("bInterval          : %xh", hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[ept].bInterval);
			}
		}

		USBD_UsrLog("\n-------------------------------------------------------.");
		 //USBH_UsrLog("USBD_Strmymanufacture : %s",USBD_Strmymanufacture);
		 //USBH_UsrLog("USBD_Strmyproduct : %s",USBD_Strmyproduct);
		 //USBH_UsrLog("USBD_Strmyserial : %s",USBD_Strmyserial);
}


void copy_DevDes_to_deviceDes(uint8_t *buf, uint8_t *des, uint16_t len)
{
	uint16_t     ptr=0;

	while (ptr < len)
	{
		des[ptr]=buf[ptr];
		ptr++;
	}
}

uint8_t timkiemendpoint (USBH_HandleTypeDef *phost, uint8_t interface, uint8_t type_data)
{
	USBH_InterfaceDescTypeDef *pif;
	USBH_CfgDescTypeDef *pcfg;
	uint8_t if_ix = 0U;

	pif = (USBH_InterfaceDescTypeDef *)0;
	pcfg = &phost->device.CfgDesc;

	while (if_ix < USBH_MAX_NUM_ENDPOINTS)
	{
		pif = &pcfg->Itf_Desc[interface];
		if(pif->Ep_Desc[if_ix].bmAttributes == type_data)
		{
			return  if_ix;
		}
		if_ix++;
	}

	return 0xFFU;
}

void remap_device()
{

	uint8_t interface =0;

	CDC_HandleTypeDef *CDC_Handle;
	USBH_HandleTypeDef *phost = &hUsbHostFS;
	CDC_Handle = (CDC_HandleTypeDef *) phost->pActiveClass->pData;

	ui8_enpoint_addressCOM =0;
	ui16_maxSizeCOM =0U;

	if (CDC_Handle->CommItf.NotifEpSize >0U)
	{
		ui8_enpoint_addressCOM 	= CDC_Handle->CommItf.NotifEp;
		ui16_maxSizeCOM			= CDC_Handle->CommItf.NotifEpSize;

		my_var_user.ui16_interval =1U;
	}

	ui8_enpoint_addressIN	= CDC_Handle->DataItf.InEp;
	ui16_maxSizeIN			= CDC_Handle->DataItf.InEpSize;
	ui8_enpoint_addressOUT	= CDC_Handle->DataItf.OutEp;
	ui16_maxSizeOUT			= CDC_Handle->DataItf.OutEpSize;

	ui8_max_ep0_size = hUsbHostFS.device.DevDesc.bMaxPacketSize;

	USBH_UsrLog("ep0_size			= %xh",ui8_max_ep0_size);
	USBH_UsrLog("addressCOM			= %xh",ui8_enpoint_addressCOM);
	USBH_UsrLog("maxSizeCOM			= %xh",ui16_maxSizeCOM);
	USBH_UsrLog("addressIN			= %xh",ui8_enpoint_addressIN);
	USBH_UsrLog("maxSizeIN			= %xh",ui16_maxSizeIN);
	USBH_UsrLog("addressOUT			= %xh",ui8_enpoint_addressOUT);
	USBH_UsrLog("maxSizeOUT			= %xh",ui16_maxSizeOUT);
}
void remap_device_old1()
{

	uint8_t interface =0;

	interface = hUsbHostFS.device.CfgDesc.bNumInterfaces;

	if(interface >1)
	{
		USBH_UsrLog("map_2_interface");
	}
	else
	{
		USBH_UsrLog("map_1_interface");
	}

	ui8_max_ep0_size = hUsbHostFS.device.DevDesc.bMaxPacketSize;

	/*chọn interface 0 phân tích*/
	interface =0;

	/*tìm endpoint command: Input, Interrupt*/
	uint8_t user_endpoint;
	user_endpoint = timkiemendpoint(&hUsbHostFS,interface,USB_EP_TYPE_INTR);
	USBH_DbgLog("user_endpoint com = %d ", user_endpoint);

	ui8_enpoint_addressCOM =0;
	ui16_maxSizeCOM =0;

	if (user_endpoint != 0xFFU)
	{
		/*Collect the notification endpoint address and length*/
		  if (hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[user_endpoint].bEndpointAddress & 0x80U)
		  {
			  USBH_DbgLog("@ interface = %d",interface);
			  USBH_DbgLog("CommItf %xh",hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[user_endpoint].bEndpointAddress);
			  USBH_DbgLog("CommItf %xh",hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[user_endpoint].wMaxPacketSize);

			  ui8_enpoint_addressCOM = hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[user_endpoint].bEndpointAddress;
			  ui16_maxSizeCOM  = hUsbHostFS.device.CfgDesc.Itf_Desc[interface].Ep_Desc[user_endpoint].wMaxPacketSize;
		  }
	}

	user_endpoint = find_endpoint(&hUsbHostFS,interface,USB_EP_TYPE_BULK);

	if (user_endpoint ==0xFFU )user_endpoint =0;

	  USBH_DbgLog("user_endpoint data = %d ", user_endpoint);

	if (hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress & 0x80U)
	  {
		ui8_enpoint_addressIN =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress;
		ui16_maxSizeIN        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].wMaxPacketSize;
	  }
	  else
	  {
		ui8_enpoint_addressOUT =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress;
		ui16_maxSizeOUT        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].wMaxPacketSize;
	  }

	user_endpoint++;
	if (hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress & 0x80U)
	  {
		ui8_enpoint_addressIN =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress;
		ui16_maxSizeIN        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].wMaxPacketSize;
	  }
	  else
	  {
		ui8_enpoint_addressOUT =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].bEndpointAddress;
		ui16_maxSizeOUT        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[user_endpoint].wMaxPacketSize;
	  }


	USBH_UsrLog("ep0_size			= %xh",ui8_max_ep0_size);
	USBH_UsrLog("addressCOM			= %xh",ui8_enpoint_addressCOM);
	USBH_UsrLog("maxSizeCOM			= %xh",ui16_maxSizeCOM);
	USBH_UsrLog("addressIN			= %xh",ui8_enpoint_addressIN);
	USBH_UsrLog("maxSizeIN			= %xh",ui16_maxSizeIN);
	USBH_UsrLog("addressOUT			= %xh",ui8_enpoint_addressOUT);
	USBH_UsrLog("maxSizeOUT			= %xh",ui16_maxSizeOUT);
}

void remap_device_old()
{

	ui8_max_ep0_size = hUsbHostFS.device.DevDesc.bMaxPacketSize;

	//enpoint address

	  if (hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[0].bEndpointAddress & 0x80U)
	  {
		ui8_enpoint_addressIN =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[0].bEndpointAddress;
		ui16_maxSizeIN        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[0].wMaxPacketSize;
	  }
	  else
	  {
		ui8_enpoint_addressOUT =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[0].bEndpointAddress;
		ui16_maxSizeOUT        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[0].wMaxPacketSize;
	  }

	  if (hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[1].bEndpointAddress & 0x80U)
	  {
		ui8_enpoint_addressIN =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[1].bEndpointAddress;
		ui16_maxSizeIN        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[1].wMaxPacketSize;
	  }
	  else
	  {
		ui8_enpoint_addressOUT =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[1].bEndpointAddress;
		ui16_maxSizeOUT        =  hUsbHostFS.device.CfgDesc.Itf_Desc[0].Ep_Desc[1].wMaxPacketSize;
	  }


	USBH_UsrLog("ep0_size			= %xh",ui8_max_ep0_size);
	USBH_UsrLog("addressIN			= %xh",ui8_enpoint_addressIN);
	USBH_UsrLog("maxSizeIN			= %xh",ui16_maxSizeIN);
	USBH_UsrLog("addressOUT			= %xh",ui8_enpoint_addressOUT);
	USBH_UsrLog("maxSizeOUT			= %xh",ui16_maxSizeOUT);
}

void xulyuart()
{
//	HAL_UART_Receive(&huart1,USER_RX_Buffer,20,0);

	if(USER_RX_Buffer[0]=='O')
	{
		USER_RX_Buffer[0]=0;
		ui8_status_esp =0U;/*ready*/
	}
	else if(USER_RX_Buffer[0]=='M')
	{
		USER_RX_Buffer[0]=0;

		ui32_timerxset =0;// reset timeout
	}
	else if(USER_RX_Buffer[0]=='E') /*gói data nhận bị lỗi, yêu cầu gửi lại*/
	{
		USER_RX_Buffer[0]=0;
		ui32_timerxset =0;// reset timeout

		ui8_package_tx--;
		quanlyESP.index_pkg--;
		u32_addr_data_user -=lentosend;

	}
	else if(USER_RX_Buffer[0]=='i')
	{
		USER_RX_Buffer[0]=0;
		SERIAL_TO_SERVER("CMD I%d %d.%d.%d", ui8_printer_status,HWVERSION,PRINTER_MODEL,RELEASEVS);
	}

	else if(USER_RX_Buffer[0]=='1')
	{

	}
	else if(USER_RX_Buffer[0]=='2')
	{
		USER_RX_Buffer[0]=0;
		SERIAL_TO_SERVER("Test ghi file");

		//test_write_byte();

	}
	else if(USER_RX_Buffer[0]=='3')
	{
		USER_RX_Buffer[0]=0;
		SERIAL_TO_SERVER("STM Flash memory");

		//test_readfile();

	}
	else if(USER_RX_Buffer[0]=='4')
	{
		USER_RX_Buffer[0]=0;
		SERIAL_TO_SERVER("get header");
		get_header();
		SERIAL_TO_SERVER("#CMD 44%d",ui32_total_data_print);
	}
	else if(USER_RX_Buffer[0]=='5')
	{
		USER_RX_Buffer[0]=0;
		//doc header
//		get_header();
		ui8_finished_printer =1U;
		u32_addr_data_user =0U;

//		ui32_total_data_print = 79766;
	}
	else if(USER_RX_Buffer[0]=='s')
	{
		USER_RX_Buffer[0]=0;
		/*xóa flash*/
//		Flash_Erase_sector(FLASH_USER_HEADDER_ADDR);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_5);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_6);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_7);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_8);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_9);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_10);
		Flash_Erase_sector(ADDR_FLASH_SECTOR_11);
		SERIAL_TO_SERVER("clear finished");
	}

}
void xuly_command_ESP()
{
	USER_RX_Buffer[0] = quanlyESP.newinchar;
	xulyuart();
}

void xuly_package_ESP()
{
//	USBH_UsrLog("rx rec = %s _END", quanlyESP.str);
/*
 #G n$
 	 G: get infor
 	 n=1: get Manufactor
 	 n=2: get model

 #R n$
 	 R: phản hồi
 	 n = 0: ACK
 	 n = 1: IDLe
 	 n = 2: Erro

 #F n$
 	 F: xóa flash
 	 n = 1 : xóa
 */
	if (quanlyESP.str[1] == 'G')
	{
		USBH_HandleTypeDef *phost;
		phost = &hUsbHostFS;
		if (quanlyESP.str[3] == '1')
		{
			USBH_UsrLog("#CMD G1 %s", phost->device.Raw_Manufacture);
		}
		else if (quanlyESP.str[3] == '2')
		{
			USBH_UsrLog("#CMD G2 %s", phost->device.Raw_Product);
		}
		else if (quanlyESP.str[3] == '3')
		{
			USBH_UsrLog("#CMD G3 %s", phost->device.Raw_Serinumber);
		}
	}
	else if (quanlyESP.str[1] == 'R')
	{
		if (quanlyESP.str[3] == '0')
		{
			ui8_status_esp =0U;/*ready*/
		}
		else if (quanlyESP.str[3] == '1')
		{
			ui32_timerxset =0;// reset timeout
		}
		else if (quanlyESP.str[3] == '2')
		{
			ui32_timerxset =0;// reset timeout

			USBH_UsrLog(" resend package ");
			if (quanlyESP.index_pkg)
			{
				quanlyESP.index_pkg--;
			}
			if (u32_addr_data_user >= lentosend)
			{
				u32_addr_data_user -=lentosend;
			}
		}
	}
	else if (quanlyESP.str[1] == 'T')
	{
		if (quanlyESP.str[3] == '1')
		{
			user_manage_request.number_printed++;
			USBH_UsrLog(" test finish printed %d", user_manage_request.number_printed);
			u32_addr_data_user =0U;
		}
		else if (quanlyESP.str[3] == '2')
		{
			USBH_UsrLog(" test format flash ");
			USBD_UsrLog("Format disk");
				/*format disk*/
			Flash_Erase_sector(ADDR_FLASH_SECTOR_5);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_6);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_7);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_8);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_9);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_10);
			Flash_Erase_sector(ADDR_FLASH_SECTOR_11);
			SERIAL_TO_SERVER("finished");
		}
		else if (quanlyESP.str[3] == '3')
		{
			USBH_UsrLog("test format");
			clear_flash();
		}
	}
	else if (quanlyESP.str[1] == 'S')
	{
		if (quanlyESP.str[3] == '1')
		{
			USBH_UsrLog("start sniff");
			pcommand->chophepsniff =1U;
			pcommand->readytopausesniff =0U;
			pcommand->timer_pausesniff = HAL_GetTick();
		}
		else if (quanlyESP.str[3] == '2')
		{
			USBH_UsrLog("end sniff");
			pcommand->chophepsniff =0U;
			pcommand->ui8_startprint =0U;
			pcommand->ui8_printing =0U;
			pcommand->WAIT_SEND_TO_SERVER =1U;
			pcommand->number_printed++;

			uint32_t diachitam = pcommand->u32_addr_header_store;
			//chỉ có 1 gói duy nhất
			pcommand->package_index =1;

			/* save total package */
			 Flash_Write_Data(diachitam, &pcommand->package_index, 1U);

			 USBD_UsrLogCog(" total package = %d \n", pcommand->package_index);

			 diachitam+=4;
			 /* save len package */
			Flash_Write_Data(diachitam, &pcommand->data_print_size, 1U);

		}
	}

	quanlyESP.busy =0;
}

uint8_t xulytruyendatalenpc()
{
	uint8_t kq =0;
	switch (quanlytruyendata.index_truyenlenpc)
	{
	case 0:
	{
		uint16_t len_rec = quanlytruyendata.chieudaidatarealdevice;

		if (len_rec > 0U)
		{
				USER_Log_NOCRLF("\t data to PC @len %d = ", len_rec);
				for (int i =0; i<len_rec; i++)
				{
					USER_Log_NOCRLF("%x",PRINTER_RX_Buffer[i]);
					USER_Log_NOCRLF(" ");
				}
				USER_Log_NOCRLF("\n");
		}

		//so sánh thông báo máy in sẵn sàng
		/*
		if(len_rec ==4U)
		{
			if (PRINTER_RX_Buffer[0] == 0x14U && PRINTER_RX_Buffer[1] == 0x00U && PRINTER_RX_Buffer[2] == 0x00U && PRINTER_RX_Buffer[3] == 0x0FU)
			{
				my_var_user.ui8_printer_status = 1U;
				ui8_printer_status =1U;
			}
		}
		*/

		USBD_HandleTypeDef *pdev = &hUsbDeviceHS;
		pdev->txtopc =1U; /* thông báo đang truyền data lên PC */
		quanlytruyendata.index_truyenlenpc =1U;
		break;
	}
	case 1:
	{
		uint16_t len_rec = quanlytruyendata.chieudaidatarealdevice;
		uint8_t tt=CDC_Transmit_HS ((uint8_t *)PRINTER_RX_Buffer, len_rec);

		if(tt == USBD_OK)
		{

//			quanlytruyendata.index_truyenlenpc =0U;
			quanlytruyendata.index_truyenlenpc =2U; //chờ truyền xong
			kq =1;

			if (len_rec > 0U)
			{
				quanlytruyendata.counter_sent_data_to_pc ++;

				USER_Log_NOCRLF("-------------Sent to PC @%d \n\n", quanlytruyendata.counter_sent_data_to_pc);
			}
		}
		else
		{
			my_var_user.ui16_counterbusy ++;
			if(my_var_user.ui16_counterbusy >100U)
			{
				my_var_user.ui16_counterbusy =0U;

				if( user_manage_request.duocphepdebug == DEBUG_OK)
				{
					USER_Log_NOCRLF("too busy??? \n");
				}

				uint8_t tam = 15U;
				tam |=0x80U;

				USBD_HandleTypeDef *mm;
				mm = &hUsbDeviceHS;

				USBD_LL_FlushEP(mm,tam);

				clear_tx_flag();
			}
		}
		break;
	}
	case 2:
	{
		USBD_HandleTypeDef *pdev = &hUsbDeviceHS;
		uint8_t t = pdev->txtopc;
		if(t==0U)
		{
			/* truyền thành công lên PC */
			quanlytruyendata.index_truyenlenpc =0U;
		}
		break;
	}
	default:
		quanlytruyendata.index_truyenlenpc =0U;
		break;
	}
	return kq;
}



void check_finishprint()
{

	if (ui16_counter_wait_printing ==0U) return;

	if (HAL_GetTick() > ui32_time_delay_next_pring)

//	ui16_counter_wait_printing ++;
//	if(ui16_counter_wait_printing > 0U)
	{
		ui16_counter_wait_printing = 0U;
		ui8_txstatustoprinter = 0U;

		if(dataprint_doing > 0) dataprint_doing --;

		if (ui8_finished_printer ==0U)
		{
			USBC_Log("dataprint_doing = %d \n",dataprint_doing );
		}

		/* check if anydata from printer*/
		if (ui8_finished_printer ==0U)
		{
			USBC_Log("\n\n Main: 1203 --------need check respone from printer-----------------------\n\n");
		}

		if ( dataprint_doing >= (MAX_USER_GET_USB_DATA - 1U))
		{
			if (ui8_finished_printer ==0U)
			{
				USBC_Log("receive enable\n");
			}
			/* in xong mới tiếp tục nhận data in từ PC*/
			ready_to_received_data();
		}

		/* chỗ này phải xác nhận lại bên máy in : in xong mới xử lý tiếp*/

	}
}

void check_data_printer()
{
	/* Đọc dữ liệu từ printer */

	if(my_var_user.ui8_chophep_docdata_tu_realdevice ==0U && my_var_user.ui16_interval ==0U) return;

	uint32_t tam = HAL_GetTick();
	if ( quanlytruyendata.timer_syncdata ==0U)
	{
		quanlytruyendata.timer_syncdata = tam + 10U;
	}

	if (tam < quanlytruyendata.timer_syncdata) return;
	//kiểm tra tx
	switch (quanlytruyendata.check_data_index)
	{
	case 0:
		/* cấu hình nhận data từ real device */
		/* sau khi gọi hàm này, thì sẽ có hàm callback USBH_CDC_ReceiveCallback được gọi tới */
		USBH_CDC_Receive(&hUsbHostFS, (uint8_t *) PRINTER_RX_Buffer, PRINTER_BUFF_SIZE);
		quanlytruyendata.check_data_index =1U;
		break;
	case 1:
		if(quanlytruyendata.codataturealdevice == 1U)
		{
				uint8_t tam =  xulytruyendatalenpc();
				if (tam ==1)
				{
					quanlytruyendata.codataturealdevice = 0U;
					quanlytruyendata.timer_syncdata =HAL_GetTick() + 10U;
					quanlytruyendata.check_data_index =0U;
				}
		}
		break;

	default:
		quanlytruyendata.check_data_index =0U;
		break;

	}
}

void test_cmd()
{
	switch (ui8_test_state)
	{

		case 0U:/* get command*/
		{

			if (ui8_finished_printer ==0U)
			{
				USBC_Log("\t test_cmd printer @len");
			}

			uint8_t cmd_temp[3];
			cmd_temp[0] =0x1DU;
			cmd_temp[1] =0x99U;
			cmd_temp[2] =0x00U;


			ui8_txstatustoprinter = 0U;

			if (USBH_CDC_Transmit (&hUsbHostFS, cmd_temp, 3U) == USBH_OK)
			 {
				  USBD_UsrLog("\tsending..\n");
			 }
			else
			{
				USBD_UsrLog("\t erro\n");
			}

			ui8_test_state=1;
			break;
		}

		default:
			ui8_user_state=0;
			break;
	}
}

void kiemtra_gui_data_to_esp()
{
	if(user_manage_request.request_tx_to_esp < user_manage_request.request_tong_nhan)
	{
		USER_REQUESET_TypeDef *pmydata;
		quanlyESP.ui16_vitridoctin = user_manage_request.request_tx_to_esp % MAX_USER_GET_USB_REQUEST;
		quanlyESP.ui16_vitriluutin = user_manage_request.request_tong_nhan % MAX_USER_GET_USB_REQUEST;
		pmydata =&user_manage_request.request_noidung[quanlyESP.ui16_vitridoctin];
		int len = pmydata->noidung_chieudai;

		if(len > 0  && pmydata->noidung_loai_request == USER_TYPE_DATA)
		{
			//truyền qua ESP
			int lennew = sprintf ((char *)PRINTER_TX_Buffer, "#CMD D%d\n%sEND", len,pmydata->noidung_data);
			  HAL_StatusTypeDef tt = HAL_UART_Transmit_IT(&huart1,PRINTER_TX_Buffer,lennew);
			  biendebug_code.u32_meas = HAL_GetTick();
			  if (tt == HAL_OK)
			  {
				  user_manage_request.request_tx_to_esp++;
				  quanlyESP.indextx =1;
			  }
		}
		else
		{
			user_manage_request.request_tx_to_esp++;
		}
	}
}

#if (0)
void process_data_to_ESP()
{
	switch (quanlyESP.indextx)
	{
	  case 0:
	  {
		  kiemtra_gui_data_to_esp();
		  break;
	  }
	  case 1:
	  {
			if (quanlyESP.status_tx_datruyenxong == 1)
			  {
#if (1)
				uint32_t tam1 = HAL_GetTick() - biendebug_code.u32_meas;
				USBH_UsrLog("#tx finish = %d %d time = %ld ms",user_manage_request.request_tx_to_esp,user_manage_request.request_tong_nhan,tam1);
#endif
				biendebug_code.counter++;
				quanlyESP.status_tx_datruyenxong =0;
				wait_res_init(1000);
				quanlyESP.indextx =2;
			  }
		  break;
	  }
	  case 2:
	  {
		  /* chờ esp rảnh */
		  check_status_esp();
		  if (ui8_status_esp ==0U)
		  {
			  quanlyESP.indextx =0;
		  }
		  break;
	  }
	  default:
		  quanlyESP.indextx =0;
		  break;
	}
}
#endif

void kiemtra_request_tu_PC()
{
	USER_REQUESET_TypeDef *pmydata;

	if(user_manage_request.request_dang_thuc_thi < user_manage_request.request_tong_nhan)
	{
		int vitridoctin = user_manage_request.request_dang_thuc_thi % MAX_USER_GET_USB_REQUEST;

		pmydata =&user_manage_request.request_noidung[vitridoctin];
		int len = pmydata->noidung_chieudai;
		int len1 = pmydata->noidung_chieudaicontrol;

		/* in  giá trị request từ PC */
		if(user_manage_request.duocphepdebug ==1U)
		{
			if(len >0U && len <64 && pmydata->noidung_loai_request == USER_TYPE_DATA)
			{
				USER_Log_NOCRLF("\n cmd @%d %d, len = %d, data: ", user_manage_request.request_dang_thuc_thi, user_manage_request.request_tong_nhan, len);

				for(int i=0; i<len; i++)
				{
					USER_Log_NOCRLF(" %02x",pmydata->noidung_data[i]);
				}
				USER_Log_NOCRLF("\n");
			}
#if (0)
			if(len1 >0U)
			{
				USER_Log_NOCRLF("\n cmd @%d %d, len = %d, control: ", user_manage_request.request_dang_thuc_thi, user_manage_request.request_tong_nhan, len);

				for(int i=0; i<len; i++)
				{
					USER_Log_NOCRLF(" %02x",pmydata->noidung_data[i]);
				}

				USER_Log_NOCRLF(">-->");

				for(int i=len; i<len + len1; i++)
				{
					USER_Log_NOCRLF(" %02x",pmydata->noidung_data[i]);
				}
				USER_Log_NOCRLF("\n");

			}
#endif
		}

		//kiểm tra lệnh set địa chỉ
		//hiện tại nếu gửi lệnh set địa chỉ thì thiết bị không hoạt động
#if (0)
		/* code chỗ này không map theo thiết bị bên ngoài*/
		user_manage_request.request_dang_thuc_thi++;

#else

			/* kiểm tra loại request */
			if(pmydata->noidung_loai_request == USER_TYPE_CONTROL)
			{
				/*if((pmydata->noidung_data[0]==0x00 && pmydata->noidung_data[1]==0x05 ) ||
								( pmydata->noidung_data[0]==0x00 && pmydata->noidung_data[1]==0x09))*/
				if(pmydata->noidung_data[0]==0x00 && pmydata->noidung_data[1]==0x05 )
				{

					if(user_manage_request.duocphepdebug ==1U)
					{
						USER_Log_NOCRLF("\t check this cmd\n");

						for(int i=0; i<len; i++)
						{
							USER_Log_NOCRLF(" %02x",pmydata->noidung_data[i]);
						}
						USER_Log_NOCRLF("\n");

					}
					user_manage_request.request_dang_thuc_thi++;
				}
				else if(pmydata->noidung_data[0]==0x02 && pmydata->noidung_data[1]==0x01 )
				{
					/*2  1  0  0  1  0  0  0*/

					USBH_HandleTypeDef *phost = &hUsbHostFS;
					CDC_HandleTypeDef *CDC_Handle;
					CDC_Handle = (CDC_HandleTypeDef *) phost->pActiveClass->pData;
					if(pmydata->noidung_data[4] & 0x80)
					{
//						USER_Log_NOCRLF("reset 1 \n");
//
//						USBH_LL_SetToggle(phost, CDC_Handle->DataItf.InPipe, 0U);
					}
					else
					{

						uint8_t tt = CDC_Handle->DataItf.OutPipe;
//						USER_Log_NOCRLF("reset 2 = %x \n", tt);

						USBH_LL_SetToggle(phost, tt, 0U);

					}
					my_var_user.ui8_user_forward_state=BOX_CMD_CONTROL;
				}
				else
				{
					/* 41 20...	gặp lệnh này là bị lỗi ???*/

					my_var_user.ui8_user_forward_state=BOX_CMD_CONTROL;
				}
			}
			else if(pmydata->noidung_loai_request == USER_TYPE_DATA)
			{
				my_var_user.ui8_user_forward_state=BOX_CMD_DATA;
			}
			else
			{
				if( user_manage_request.duocphepdebug == DEBUG_OK)
				{
					USER_Log_NOCRLF("\t unknow this data = %02x \n", pmydata->noidung_loai_request);

					USER_Log_NOCRLF("\n cmd @%d %d, len = %d, data: ", user_manage_request.request_dang_thuc_thi, user_manage_request.request_tong_nhan, len);

					for(int i=0; i<len; i++)
					{
						USER_Log_NOCRLF(" %02x",pmydata->noidung_data[i]);
					}
					USER_Log_NOCRLF("\n");
				}
				user_manage_request.request_dang_thuc_thi++;
			}

#endif
	}


	/*kiểm tra khởi tạo lại nhận data*/

	if (user_manage_request.need_getreadyrx ==1U)
	{
		uint16_t gap1 = user_manage_request.request_tong_nhan - user_manage_request.request_dang_thuc_thi;
		if (gap1 < MAX_REQUEST_RX_RESTART)
		{
			USER_Log_NOCRLF("get data again \n");
			user_manage_request.need_getreadyrx =0U;
			ready_to_received_data();
		}
	}
}
void box_forward_control_real_device_to_PC()
{

	uint32_t  size = USBH_LL_GetLastXferSize(&hUsbHostFS, hUsbHostFS.Control.pipe_in);
	uint8_t *pbuf = PRINTER_CTL_Buffer;

	for(int i=0;i<size;i++)
	{
		pbuf[i] = hUsbHostFS.Control.buff[i];
	}

	if (size > 0U)
    {
    	//len = MIN(len, req->wLength);

      (void)USBD_CtlSendData(&hUsbDeviceHS, pbuf, (uint16_t)size);
    }
	else
    {
      (void)USBD_CtlSendStatus(&hUsbDeviceHS);
    }
}

void xulychuyentiepdata()
{
	switch (my_var_user.ui8_user_forward_state)
		  {
		  case BOX_STATE_IDLE:/* get command*/
		  {

	//		  xulydatain();

			  //đọc request từ PC gửi xuống
			  kiemtra_request_tu_PC();

			  break;
		  }
		  case BOX_CMD_CONTROL: /* control cmd*/
		  {
			  USER_REQUESET_TypeDef *pmydata;

			  int vitridoctin = user_manage_request.request_dang_thuc_thi % MAX_USER_GET_USB_REQUEST;
			  pmydata =&user_manage_request.request_noidung[vitridoctin];

			  USBH_StatusTypeDef Status;

			  /* kiểm tra có data control cần gửi hay không */
			  int chieudaidatacontrol = pmydata->noidung_chieudaicontrol;

			  if (chieudaidatacontrol > 0U)
			  {
				  Status = USBH_send_request_datacontrol_toprinter(&hUsbHostFS,pmydata->noidung_data,pmydata->noidung_data+8,chieudaidatacontrol);
			  }
			  else
			  {
				  Status = USBH_guilenhtestquaprinter(&hUsbHostFS,pmydata->noidung_data);
			  }

			  if (Status == USBH_OK)
				{
					/* Commands successfully sent and Response Received  */
				  my_var_user.ui8_user_forward_state=BOX_CONTROL_TO_PC;
				}
				else if (Status == USBH_NOT_SUPPORTED)
				{
					/* Commands successfully sent and Response Received  */
	/*				if( user_manage_request.duocphepdebug == DEBUG_OK)
					{
						USBH_UsrLog("\t from real device : USBH_NOT_SUPPORTED");
					}*/

	//				(void)USBD_CtlError(&hUsbDeviceHS, &hUsbDeviceHS.request);
					USBD_LL_StallEP(&hUsbDeviceHS, 0x80U);

					my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
				}
				else
				{
					if (Status == USBH_FAIL)
					{
						/* Failure Mode */
						if( user_manage_request.duocphepdebug == DEBUG_OK)
						{
							USBH_UsrLog("\t from real device: USBH_FAIL");
						}
						my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
					}
				}
			  break;
		  }
			case BOX_CONTROL_TO_PC:
			{

				box_forward_control_real_device_to_PC();

			    my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
				break;
			}
			case BOX_CMD_DATA: /* control cmd*/
			  {
				  uint16_t lll = 0U;
				  USER_REQUESET_TypeDef *pmydata;

				  int vitridoctin = user_manage_request.request_dang_thuc_thi % MAX_USER_GET_USB_REQUEST;
				  pmydata =&user_manage_request.request_noidung[vitridoctin];

				  lll = pmydata->noidung_chieudai;

				  quanlytruyendata.txtorealdevice = 0U;
				  USBH_StatusTypeDef Status = USBH_CDC_Transmit(&hUsbHostFS,pmydata->noidung_data, lll);

				  if (Status == USBH_OK)
					{
					  /* vào đây mới chỉ đưa data vào trong buffer để sẵn sàng truyền đi */
					  /* kiểm tra trạng thái cờ */

					  if( user_manage_request.duocphepdebug == DEBUG_OK)
					  {
						  if(lll > 0U && lll < 64U)
						  {
							  USBH_UsrLog("\t Sending to device @len = %d, exe =%d",(uint16_t)lll, user_manage_request.request_dang_thuc_thi);
						  }
					  }

					  quanlytruyendata.timesend = HAL_GetTick() + 5000;
					  my_var_user.ui8_user_forward_state=BOX_WAIT_DATA_FROM_PRINTER;/* BOX_GET_NEXT */

					}
					else
					{
						if( user_manage_request.duocphepdebug == DEBUG_OK)
						{
							USBH_UsrLog("\t Erro: send to printer @len = %d, cmd = %d",(uint16_t)lll, vitridoctin);
						}
					}
				  break;
			  }
			case BOX_WAIT_DATA_FROM_PRINTER:
			{
				/* kiểm tra timeout */
				uint32_t tam = HAL_GetTick();
				if(tam > quanlytruyendata.timesend)
				{
					if( user_manage_request.duocphepdebug == DEBUG_OK)
					{
						USBH_UsrLog("\t ------------Erro: timeout send to printer");
					}
					my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
				}

				if(quanlytruyendata.txtorealdevice == 1U)
				{
					quanlytruyendata.txtorealdevice = 0U;
					my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
				}
				else if(quanlytruyendata.txtorealdevice == 2U)
				{
					quanlytruyendata.txtorealdevice = 0U;
					//set stall
					uint8_t t = ui8_enpoint_addressOUT;

					USBH_UsrLog("\t ---set stall-- %x", t);

					USBD_LL_StallEP(&hUsbDeviceHS, t);

					ready_to_received_data();
					my_var_user.ui8_user_forward_state=BOX_GET_NEXT;
				}

				break;
			}
			case BOX_GET_NEXT:
			{
				//đã thực thi xong lệnh này, trỏ tới lệnh tiếp theo
				user_manage_request.request_dang_thuc_thi++;
				my_var_user.ui8_user_forward_state=BOX_STATE_IDLE;
				break;
			}
		  }


	check_data_printer();

}
/*thiết lập truyền data qua ESP*/
void wait_res_init(uint32_t timeout_wait_)
{
	ui32_timerxset = HAL_GetTick() + timeout_wait_;
	ui8_status_esp =1U;

}

int check_status_esp()
{
	int kq =1;
	if (ui8_status_esp ==0U) return 0; /*idle*/

	uint32_t tam = HAL_GetTick();

	if(tam > ui32_timerxset)
	{
		/*
		 nếu timeout thì truyền lại gói check
		 đến khi nào ready mới xử lý truyền
		*/
		SERIAL_TO_SERVER("#CMD RD");
		ui32_timerxset = HAL_GetTick() + 1000;
		ui32_counter_send_status=HAL_GetTick() + 25000;

		//kq =0;
		//ui8_status_esp =0U;

		/*nếu timeout thì truyền lại gói khởi động
		 chờ ESP sẵn sàng nhận dữ liệu
		 * */

		//if(u32_addr_data_user == FLASH_USER_START_ADDR)
		//{
			//u32_addr_data_user =0;
		//}
	}

	return kq;
}

uint32_t get_addr_header()
{
	uint32_t kq=0;
	int vitridoctin = user_manage_request.number_printed_processing % MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME;

	 if(vitridoctin ==1)
	 {
		 kq =FLASH_USER_HEADDER_ADDR2;
	 }
	 else
	 {
		 kq =FLASH_USER_HEADDER_ADDR;
	 }
	 return kq;
}
uint32_t get_addr_data()
{
	uint32_t kq=0;
	int vitridoctin = user_manage_request.number_printed_processing % MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME;

	 if(vitridoctin ==1)
	 {
		 kq =FLASH_USER_START_ADDR2;
	 }
	 else
	 {
		 kq =FLASH_USER_START_ADDR;
	 }
	 return kq;
}
#if (0)
void xuly_data_print()
{
	if (ui8_finished_printer)
	{
		//kiểm tra status ESP
		check_status_esp();
		if (ui8_status_esp ==1U) return;

		uint32_t Rx_Dataread[1024];
		 uint32_t tt;
		 uint32_t tt2;
		 int numofwords;
		 uint8_t ss[20];
		 uint8_t u[5];

		 //load giá trị ban đầu
		if (u32_addr_data_user == 0U)
		{
			get_header();
			ui32_package_index_sending =0U;
			get_nextdata();
			u32_addr_data_user = get_addr_data();
			ui8_package_tx =0U;
			//bắt đầu in
			SERIAL_TO_SERVER("#CMD 11%d",ui32_total_data_print);

			/*kiểm tra phải có phản hồi từ esp mới tiến hành bước tiếp theo*/

			wait_res_init(1000);
			return;
		}

		if (ui32_txprinterlength > 0U)
		{
				/* truyền data*/
				if (ui32_txprinterlength > BUFFER_TX_SERVER_SIZE)
				{
					ui32_txprinterlength-=BUFFER_TX_SERVER_SIZE;
					lentosend = BUFFER_TX_SERVER_SIZE;
				}
				else
				{
					lentosend = ui32_txprinterlength;
					ui32_txprinterlength =0U;
				}

				numofwords = (lentosend/4)+((lentosend%4)!=0);

				tt = HAL_GetTick();
				Flash_Read_Data(u32_addr_data_user, Rx_Dataread, numofwords);
				tt2 = HAL_GetTick();
				tt2 -= tt;

//				USBD_CongLog("\n Read index =%d, addr = %X, size = %d words, time = %d\n",ui8_package_tx, u32_addr_data_user , numofwords, tt2);

				int so_byte_da_truyen = 4*(numofwords -1);
				int so_byte_conphaitruyen = lentosend - so_byte_da_truyen;
//				USBD_CongLog("\n byte main =%d, sub = %d \n",so_byte_da_truyen, so_byte_conphaitruyen);

				sprintf (ss, "#CMD P%dL%04d", ui8_package_tx, (uint16_t)lentosend);
				SERIAL_TO_SERVER(ss);

				//chờ phản hồi mới truyền data qua

				/*truyền khúc đầu*/
				for(int i =0; i< numofwords-1 ; i++)
				{
					convertdata(Rx_Dataread[i] , u);
					HAL_UART_Transmit(&huart1,u,4,0xFFFF);
				}

				/*truyền khúc cuối*/

				convertdata(Rx_Dataread[numofwords-1] , u);
				HAL_UART_Transmit(&huart1,u,so_byte_conphaitruyen,0xFFFF);

				SERIAL_TO_SERVER("EOP");
				SERIAL_TO_SERVER("endpackage");

				ui8_package_tx++;
				u32_addr_data_user +=lentosend;
				wait_res_init(1000);
		}
		else
		{
			/*kiểm tra xem còn gói package nào không*/
			if (ui32_package_index_sending < ui32_package_index_total)
			{
				/*get next package*/
				get_nextdata();

			}
			else
			{
				/* kết thúc truyền*/
				SERIAL_TO_SERVER("#CMD 10");
				ui8_finished_printer =0U;
				u32_addr_data_user = 0U;
				user_manage_request.number_printed_processing++;
				wait_res_init(1000);

				//chờ truyền hết data buffer qua esp: mới cho in tiếp
				USBD_CongLog("------------receive next print: check again-------------- \n");
//				ready_to_received_data();
			}
		}
	}
	else
	{
		ui8_status_esp =1U;
		//kiểm tra xem có data in hay không
		if (user_manage_request.number_printed_processing < user_manage_request.number_printed)
		{
			ui8_finished_printer =1;
		}
	}
}
#endif

void clear_flash()
{
#if (DEBUG_NO_ERASER_FLASH ==10U)
	USBD_UsrLog(" clear_flash: DEBUG_NO_ERASER_FLASH");

#else
	uint32_t diachicanxoa = get_addr_header();
	uint16_t numberofwords = (ui32_total_data_print/4)+((ui32_total_data_print%4)!=0);
	Flash_Erase_sector_leng(diachicanxoa, numberofwords);
	SERIAL_TO_SERVER("clear @%x, len = %ld", diachicanxoa, ui32_total_data_print);
#endif
}
void set_erro()
{
	SERIAL_TO_SERVER(" set_erro ");
	/*xóa flash sau khi truyền qua esp*/
	clear_flash();
	ui8_finished_printer =0U;
	u32_addr_data_user = 0U;
	user_manage_request.number_printed_processing++;
}
void check_data_print()
{
	if (ui8_finished_printer)
	{
		//kiểm tra status ESP
		uint32_t Rx_Dataread[1024];
		 int numofwords;
		 uint8_t u[5];

		 //load giá trị ban đầu
		if (u32_addr_data_user == 0U)
		{
			int eroo = get_header();
			if(eroo)
			{
				set_erro();
				return;
			}
			else
			{
				ui32_package_index_sending =0U;
				ui32_data_offset =0;
				eroo = get_nextdata();

				if (eroo)
				{
					set_erro();
					return;
				}
				else
				{
					u32_addr_data_user = get_addr_data();
					quanlyESP.index_pkg =0U;
					//bắt đầu in
		//			SERIAL_TO_SERVER("#CMD 11%d",ui32_total_data_print);
					quanlyESP.lentx = sprintf ((char *)PRINTER_TX_Buffer, "#CMD 11%d\n", ui32_total_data_print);
					quanlyESP.cmd_tx =1U;
					return;
				}
			}
		}

		if (ui32_txprinterlength > 0U)
		{
				/* truyền data*/
				if (ui32_txprinterlength > BUFFER_TX_SERVER_SIZE)
				{
					ui32_txprinterlength-=BUFFER_TX_SERVER_SIZE;
					lentosend = BUFFER_TX_SERVER_SIZE;
				}
				else
				{
					lentosend = ui32_txprinterlength;
					ui32_txprinterlength =0U;
				}

				numofwords = (lentosend/4)+((lentosend%4)!=0);
				Flash_Read_Data(u32_addr_data_user, Rx_Dataread, numofwords);

				int so_byte_da_truyen = 4*(numofwords -1);
				int so_byte_conphaitruyen = lentosend - so_byte_da_truyen;

				int tamtru = sprintf ((char *)PRINTER_TX_Buffer, "#CMD P%dL%04d", quanlyESP.index_pkg, (uint16_t)lentosend);

				PRINTER_TX_Buffer[tamtru]='\n';
				tamtru++;

				/*truyền khúc đầu*/
				for(int i =0; i< numofwords-1 ; i++)
				{
					convertdata(Rx_Dataread[i] , u);
//					HAL_UART_Transmit(&huart1,u,4,0xFFFF);
					PRINTER_TX_Buffer[tamtru]=u[0];
					PRINTER_TX_Buffer[tamtru+1]=u[1];
					PRINTER_TX_Buffer[tamtru+2]=u[2];
					PRINTER_TX_Buffer[tamtru+3]=u[3];
					tamtru += 4;
				}

				/*truyền khúc cuối*/

				convertdata(Rx_Dataread[numofwords-1] , u);
//				HAL_UART_Transmit(&huart1,u,so_byte_conphaitruyen,0xFFFF);
				for(int m =0;m<so_byte_conphaitruyen;m++)
				{
					PRINTER_TX_Buffer[tamtru]=u[m];
					tamtru++;
				}
//				SERIAL_TO_SERVER("EOP");
//				SERIAL_TO_SERVER("endpackage");

				PRINTER_TX_Buffer[tamtru]='E';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='O';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='P';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='\n';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='e';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='o';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='p';
				tamtru++;
				PRINTER_TX_Buffer[tamtru]='\n';
				tamtru++;

				quanlyESP.index_pkg ++;
				u32_addr_data_user +=lentosend;
				quanlyESP.lentx =tamtru;
				quanlyESP.cmd_tx =1U;
		}
		else
		{
			/*kiểm tra xem còn gói package nào không*/
			if (ui32_package_index_sending < ui32_package_index_total)
			{
				/*get next package*/
				get_nextdata();
			}
			else
			{
				/* kết thúc truyền*/
//				SERIAL_TO_SERVER("#CMD 10");

				quanlyESP.lentx = sprintf ((char *)PRINTER_TX_Buffer, "#CMD 10\n");
				quanlyESP.cmd_tx =1U;

				/*xóa flash sau khi truyền qua esp*/
//				USBD_UsrLog(" !!!!!!!!!!! ------------debug 1957: uncomment this line");

				clear_flash();

				wait_res_init(1000);

				ui8_finished_printer =0U;
				u32_addr_data_user = 0U;
				user_manage_request.number_printed_processing++;
				user_manage_request.duocphepdebug =DEBUG_OK;
			}
		}
	}
	else
	{
		ui8_status_esp =1U;
		quanlyESP.cmd_tx =0U;
		//kiểm tra xem có data in hay không
		if (user_manage_request.number_printed_processing < user_manage_request.number_printed)
		{
			ui8_finished_printer =1;
			user_manage_request.duocphepdebug =DEBUG_BUSY;
		}
	}
}
/* transmit_to_esp_process
 * dùng ngắt tx truyền qua ESP
 *
 *
 */
void transmit_to_esp_process()
{
	switch (quanlyESP.indextx)
	{
	  case ESP_INIT:
	  {
		  ui8_status_esp =1U;
		  quanlyESP.indextx =ESP_WAIT_ESPIDLE;
		  break;
	  }
	  case ESP_WAIT_ESPIDLE:
	  {
		  /* chờ esp rảnh */
		  check_status_esp();
		  if (ui8_status_esp ==0U)
		  {
			  quanlyESP.indextx =ESP_STATE_SETUP;
		  }
		  break;
	  }
	  case ESP_STATE_SETUP:/* idle */
	  {
		  HAL_StatusTypeDef tt = HAL_UART_Transmit_IT(&huart1,PRINTER_TX_Buffer,quanlyESP.lentx);
		  if (tt == HAL_OK)
		  {
			  quanlyESP.indextx =ESP_WAITSEND;
		  }
		  break;
	  }
	  case ESP_WAITSEND:
	  {
			if (quanlyESP.status_tx_datruyenxong == 1)
			  {
#if (0)
				uint32_t tam1 = HAL_GetTick() - biendebug_code.u32_meas;
				USBH_UsrLog("#tx finish = %d %d time = %ld ms",user_manage_request.request_tx_to_esp,user_manage_request.request_tong_nhan,tam1);
#endif
				quanlyESP.cmd_tx =0U;
				quanlyESP.status_tx_datruyenxong =0;
				quanlyESP.indextx =ESP_INIT;
			  }
		  break;
	  }

	  default:
		  quanlyESP.indextx =ESP_INIT;
		  break;
	}
}
/*
 * xuly_data_print_itx()
 *
 *
 */
void xuly_data_print_itx()
{
	if (quanlyESP.cmd_tx == 1U)
	{
		transmit_to_esp_process();
	}
	else
	{
		check_data_print();
	}
}

void test_readfile()
{
	SERIAL_TO_SERVER("--------------Test read file------------------------------\n");

	uint32_t Rx_Data[30];
	uint16_t lentosend;
	uint32_t Rx_Dataread[1024];
	uint8_t datatest[4096];
	uint8_t tam =0;
	 uint32_t tt;
	 uint32_t tt2;
	 int numofwords;
	 uint8_t ss[20];
	 uint8_t u[5];


				u32_addr_data_user =FLASH_USER_START_ADDR;
	#if (1)
				for (int t =0; t<10 ; t++)
				{

					lentosend = 4096;
					numofwords = (lentosend/4)+((lentosend%4)!=0);

					tt = HAL_GetTick();
					Flash_Read_Data(u32_addr_data_user, Rx_Dataread, numofwords);
					tt2 = HAL_GetTick();
					tt2 -= tt;
					//	  Convert_To_Str(Rx_Data, string);
					USBD_CongLog("\n Read index =%d, addr = %x, size = %d words, time = %d\n",t, u32_addr_data_user , numofwords, tt2);

					sprintf (ss, "read @%d len = %04d", t, (uint16_t)lentosend);
					SERIAL_TO_SERVER(ss);

					for(int i =0; i< numofwords; i++)
					{
						convertdata(Rx_Dataread[i] , u);
//						HAL_UART_Transmit(&huart1,u,4,0xFFFF);
						USER_Log_NOCRLF("%02X %02X %02X %02X ",u[0],u[1],u[2],u[3]);
					}

					USBD_CongLog("end \n");

//					SERIAL_TO_SERVER("CMD I%d %s", ui8_printer_status,VERSION_NAME);
					SERIAL_TO_SERVER("CMD I%d %d.%d.%d", ui8_printer_status,HWVERSION,PRINTER_MODEL,RELEASEVS);

					u32_addr_data_user +=lentosend;
					HAL_Delay(2000);

				}
	#endif

				lentosend = 3208;

				numofwords = (lentosend/4)+((lentosend%4)!=0);

				Flash_Read_Data(u32_addr_data_user, Rx_Dataread, numofwords);
				//	  Convert_To_Str(Rx_Data, string);

				SERIAL_TO_SERVER("\n Read index =%d, addr = %x, size = %d words, time = %d\n",30U, u32_addr_data_user , numofwords, tt2);


				sprintf (ss, "read @%d len = %04d", 30, (uint16_t)lentosend);
				SERIAL_TO_SERVER(ss);

				for(int i =0; i< numofwords; i++)
				{
					convertdata(Rx_Dataread[i] , u);
					HAL_UART_Transmit(&huart1,u,4,0xFFFF);
				}


				SERIAL_TO_SERVER("\n\n");

				SERIAL_TO_SERVER("--------------End Test read file------------------------------\n");

}

int get_header()
{
	int kq =0;
	USBD_CongLog("--------------get_header------------------------------\n");

	 uint32_t totaltam =0;

	u32_addr_data_user =get_addr_header();

	/*đọc tổng số package */

	uint32_t pp =0;
	ui32_total_data_print =0;

	Flash_Read_Data(u32_addr_data_user, &pp, 1U);
	ui32_package_index_total = pp;

	u32_addr_data_user += 4; //địa chỉ gói đầu tiên
	USBD_CongLog("total package =%d\n",pp);

	if(pp==1)
	{
		Flash_Read_Data(u32_addr_data_user, &totaltam, 1U);
		ui32_total_data_print = totaltam;
		USBD_UsrLogCog(" read 1 package = %ld \n", ui32_total_data_print);
	}
	else if (pp > 0 && pp < 10)
	{
		ui32_total_data_print =0U;
		uint32_t quai[6];
		Flash_Read_Data(u32_addr_data_user, quai, 5U);

		int uu = (int)pp;
		for (int kk = 0; kk < uu; kk++)
		 {
//			 Flash_Read_Data(u32_addr_data_user, &totaltam, 1U);

			totaltam=quai[kk];
			ui32_total_data_print += totaltam;

			 u32_addr_data_user += 4;

			 USBD_UsrLogCog(" index = %d, addr = %x, len1 = %ld, total = %ld \n", kk, u32_addr_data_user, totaltam, ui32_total_data_print);
		 }
	}
	else
	{
		kq =1;
	}

	if (ui32_total_data_print > 3*128*1024)/* 3 sector *128k*/
	{
		ui32_total_data_print =0;
		USBD_UsrLogCog(" set totallen = 0 \n");
		kq=1;
	}

	USBD_CongLog("Read =%d\n",ui32_total_data_print);

	USBD_CongLog("--------------End get_header------------------------------\n");
	return kq;
}

int get_nextdata()
{
	int kq =0;
	USBD_CongLog("--------------get_nextdata------------------------------\n");
	/* offset cho data tiếp theo */
	u32_addr_data_user += ui32_data_offset;
	USBD_UsrLogCog(" u32_addr_data_user = %x \n", u32_addr_data_user);

	 uint32_t totaltam =0;
	 uint32_t diachitam =0;
	 uint32_t tam =0;
	/*lấy địa chỉ tạm*/

	 diachitam = ui32_package_index_sending*4;
	 tam = get_addr_header();
	 diachitam += tam;//offset
	 diachitam += 4;//bỏ qua total package

	 Flash_Read_Data(diachitam, &totaltam, 1U);

	 USBD_UsrLogCog(" new package %d, len1 = %ld \n", ui32_package_index_sending, totaltam);

	 /* dời offset data */
	 int u = totaltam %4;
	if (u)
	{
		ui32_data_offset = 4 -u;
		USBD_UsrLogCog(" next offset data = %d \n", ui32_data_offset);
	}


	 ui32_txprinterlength = totaltam;

	if (ui32_txprinterlength > 3*128*1024)/* 3 sector *128k*/
	{
		ui32_txprinterlength =0;
		USBD_UsrLogCog(" set len = 0 \n");
		kq =1;
	}

	 ui32_package_index_sending++; //chỉ tới gói tiếp theo
	USBD_CongLog("--------------End get_nextdata------------------------------\n");
	return kq;
}
void test_write()
{
	USBD_UsrLog("Test read/write flash");
	uint16_t lentosend;
	uint8_t datatest[4096];
	uint8_t tam =0;
	 uint32_t tt;
	 uint32_t tt2;

	 uint32_t totaltam =0;
	int numofwords;

#if (0)

	  Flash_Write_Data(0x08020000 , (uint32_t *)data2, 9);


	  Flash_Read_Data(0x08020000 , Rx_Data, 10);

	  USBD_UsrLog("Rx_Data 1 = ");
		for(int i =0; i< 9; i++)
		{

			USBD_CongLog("%02x ",Rx_Data[i]);

		}
		USBD_CongLog("\n");
#endif



#if (0)
	  numofwords = (strlen(data)/4)+((strlen(data)%4)!=0);

	  tt = HAL_GetTick();

	  Flash_Write_Data(0x08021000 , (uint32_t *)data, numofwords);

		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog(" Time = %d \n",tt2);


	  Flash_Read_Data(0x08021000 , Rx_Data, numofwords);
//	  Convert_To_Str(Rx_Data, string);
	  USBD_UsrLog("Rx_Data 2 = ");
		for(int i =0; i< numofwords; i++)
		{

			USBD_CongLog("%02x ",Rx_Data[i]);

		}
		USBD_CongLog("\n");
#endif

		/*Khởi tạo giá trị test*/
		tam = 0;
		for(int j =0; j < 4096; j++)
		{
			datatest[j] = tam;

				tam++;
				if (tam > 0xff) tam = 0;
		}

		/*xóa vùng nhớ*/
		Flash_Erase_sector(FLASH_USER_START_ADDR);

		u32_addr_data_user =FLASH_USER_START_ADDR;

#if (1)
		lentosend =0x40U;
		totaltam+=lentosend;

		numofwords = (lentosend/4)+((lentosend%4)!=0);
		tt = HAL_GetTick();
		Flash_Write_Data(u32_addr_data_user, (uint32_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",0U, u32_addr_data_user , numofwords, tt2);
		u32_addr_data_user +=lentosend;

		//chiều dài là số lẻ 4 thì bị sai?????????????????
		lentosend =0x15U;
//		lentosend =0x18U;

		int du = lentosend %4;
		int offset =0;
		if(du)
		{
			offset = 4-du;
			USBD_CongLog("tam = %d, offset = %d \n", du, offset);

		}
		lentosend+=offset;

		totaltam+=lentosend;

		numofwords = (lentosend/4)+((lentosend%4)!=0);
		tt = HAL_GetTick();
		Flash_Write_Data(u32_addr_data_user, (uint32_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",1U, u32_addr_data_user , numofwords, tt2);
		u32_addr_data_user +=lentosend;
#endif


#if (1)
		for (int t =0;t<10;t++)
		{
			lentosend =4096;
			totaltam+=lentosend;

			numofwords = (lentosend/4)+((lentosend%4)!=0);

			/* Ghi lan t */

			tt = HAL_GetTick();
			Flash_Write_Data(u32_addr_data_user, (uint32_t *)datatest, numofwords);
			tt2 = HAL_GetTick();
			tt2 -= tt;
			USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",t, u32_addr_data_user , numofwords, tt2);

			u32_addr_data_user +=lentosend;
		}
#endif

		lentosend =3208;
		totaltam+=lentosend;
		numofwords = (lentosend/4)+((lentosend%4)!=0);

		tt = HAL_GetTick();
		Flash_Write_Data(u32_addr_data_user, (uint32_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",30U, u32_addr_data_user , numofwords, tt2);


		/* ghi vào header*/
		u32_addr_data_user = get_addr_header();
		numofwords =1;
		USBD_CongLog("\n Total size = %lu bytes\n",totaltam);
		Flash_Write_Data(u32_addr_data_user, &totaltam, numofwords);

		USBD_CongLog("--------------End Test write file------------------------------\n");

}

void test_write_byte()
{
	USBD_UsrLog("Test read/write flash");
	uint16_t lentosend;
	uint8_t datatest[4096];
	uint8_t tam =0;
	 uint32_t tt;
	 uint32_t tt2;

	 uint32_t totaltam =0;
	int numofwords;

#if (0)

	  Flash_Write_Data(0x08020000 , (uint32_t *)data2, 9);


	  Flash_Read_Data(0x08020000 , Rx_Data, 10);

	  USBD_UsrLog("Rx_Data 1 = ");
		for(int i =0; i< 9; i++)
		{

			USBD_CongLog("%02x ",Rx_Data[i]);

		}
		USBD_CongLog("\n");
#endif



#if (0)
	  numofwords = (strlen(data)/4)+((strlen(data)%4)!=0);

	  tt = HAL_GetTick();

	  Flash_Write_Data(0x08021000 , (uint32_t *)data, numofwords);

		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog(" Time = %d \n",tt2);


	  Flash_Read_Data(0x08021000 , Rx_Data, numofwords);
//	  Convert_To_Str(Rx_Data, string);
	  USBD_UsrLog("Rx_Data 2 = ");
		for(int i =0; i< numofwords; i++)
		{

			USBD_CongLog("%02x ",Rx_Data[i]);

		}
		USBD_CongLog("\n");
#endif

		/*Khởi tạo giá trị test*/
		tam = 0;
		for(int j =0; j < 4096; j++)
		{
			datatest[j] = tam;

				tam++;
				if (tam > 0xff) tam = 0;
		}

		/*xóa vùng nhớ*/
		Flash_Erase_sector(FLASH_USER_START_ADDR);

		u32_addr_data_user =FLASH_USER_START_ADDR;

#if (1)
		lentosend =0x40U;
		totaltam+=lentosend;

		numofwords = lentosend;
		tt = HAL_GetTick();
		Flash_Write_byte(u32_addr_data_user, (uint8_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",0U, u32_addr_data_user , numofwords, tt2);
		u32_addr_data_user +=lentosend;

		//chiều dài là số lẻ 4 thì bị sai?????????????????
		lentosend =0x15U;
//		lentosend =0x18U;

		totaltam+=lentosend;

		numofwords = lentosend;
		tt = HAL_GetTick();
		Flash_Write_byte(u32_addr_data_user, (uint8_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",1U, u32_addr_data_user , numofwords, tt2);
		u32_addr_data_user +=lentosend;
#endif


#if (1)
		for (int t =0;t<10;t++)
		{
			lentosend =4096;
			totaltam+=lentosend;

			numofwords = lentosend;

			/* Ghi lan t */

			tt = HAL_GetTick();
			Flash_Write_byte(u32_addr_data_user, (uint8_t *)datatest, numofwords);
			tt2 = HAL_GetTick();
			tt2 -= tt;
			USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",t, u32_addr_data_user , numofwords, tt2);

			u32_addr_data_user +=lentosend;
		}
#endif

		lentosend =3208;
		totaltam+=lentosend;
		numofwords = lentosend;

		tt = HAL_GetTick();
		Flash_Write_byte(u32_addr_data_user, (uint8_t *)datatest, numofwords);
		tt2 = HAL_GetTick();
		tt2 -= tt;
		USBD_CongLog("\n Write index =%d, addr = %x, size = %d, time = %d\n",30U, u32_addr_data_user , numofwords, tt2);


		/* ghi vào header*/
		u32_addr_data_user = get_addr_header();
		numofwords =1;
		USBD_CongLog("\n Total size = %lu bytes\n",totaltam);
		Flash_Write_Data(u32_addr_data_user, &totaltam, numofwords);

		USBD_CongLog("--------------End Test write file------------------------------\n");

}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_UART5_Init();
  /*MX_USB_DEVICE_Init();*/
  MX_USB_HOST_Init();
  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_14,0);

  /* select DP9 */
  HAL_GPIO_WritePin(RS232_En1_GPIO_Port,RS232_En1_Pin,0);
  HAL_GPIO_WritePin(RS232_En2_GPIO_Port,RS232_En2_Pin,1);

  /*power enable*/
  HAL_GPIO_WritePin(CTR_RS232_POWER_GPIO_Port,CTR_RS232_POWER_Pin,0);

  HAL_UART_Receive_IT(&huart1, quanlyESP.RX_buf,1);

#if (0)
  for (int i =0;i<4;i++)
	{
		HAL_GPIO_TogglePin(LedSys_GPIO_Port,LedSys_Pin);
		HAL_Delay(200);
	}
#endif

	SERIAL_TO_SERVER("-------Intercept box 1st Version-------------------------------.");
//	USBH_UsrLog("-------VNov022023 16h18---------------------------------------------.");
//	SERIAL_TO_SERVER(VERSION_NAME);
	SERIAL_TO_SERVER("CMD I%d %d.%d.%d", ui8_printer_status,HWVERSION,PRINTER_MODEL,RELEASEVS);
	SERIAL_TO_SERVER("App started.");
	SERIAL_TO_SERVER("---------------------------------------------------------------.");

	USBD_UsrLog("r. Read file from spiffs");



	USBD_UsrLog("Format disk");
	/*format disk*/
#if (DEBUG_NO_ERASER_FLASH ==10U)
	USBD_UsrLog(" !!!!!!!!!!! ------------debug 2571: DEBUG_NO_ERASER_FLASH");

#else


#if (usingchip == chip1M)
	Flash_Erase_sector(ADDR_FLASH_SECTOR_5);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_6);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_7);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_8);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_9);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_10);
	Flash_Erase_sector(ADDR_FLASH_SECTOR_11);
#else
	Flash_Erase_sector(ADDR_FLASH_SECTOR_5);
#endif

	SERIAL_TO_SERVER("finished");
#endif

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  if (Appli_state == APPLICATION_READY)
	  {
		  if(ui8_need_reinint ==0U)
		  {
			ui8_need_reinint =1U;
			printinfoDevice();
			remap_device();
			user_init_values();

			USBD_UsrLog("----------start USB_DEVICE_Init-----------------------------------------------------.");
			MX_USB_DEVICE_Init();

			//USBD_LL_Reset();
			//USBD_SetClassConfig(&hUsbDeviceHS, 0);

			USBD_UsrLog("----------end USB_DEVICE_Init-----------------------------------------------------.");

		  }
		  xulychuyentiepdata();
		  HAL_GPIO_WritePin(LedUSB_A_GPIO_Port,LedUSB_A_Pin,0);

		  if(ui16_counter_sent_data_to_pc > 6U)
		  {
			  HAL_GPIO_WritePin(LedUSB_B_GPIO_Port,LedUSB_B_Pin,0);
		  }
		  //thông báo có thiết bị gắn vào
		  my_var_user.ui8_printer_status = 1U;
		  ui8_printer_status =1U;
	  }
	  else
	  {
		  if(ui8_need_reinint ==1U)
		  {
			ui8_need_reinint =0U;
			USBD_UsrLog("----------start USB_DEVICE_DeInit-----------------------------------------------------.");
			USBD_DeInit(&hUsbDeviceHS);

			user_init_values();
		  }

		  HAL_GPIO_WritePin(LedUSB_A_GPIO_Port,LedUSB_A_Pin,1);
		  HAL_GPIO_WritePin(LedUSB_B_GPIO_Port,LedUSB_B_Pin,1);
		  ui8_need_reinint =0U;
		  ui16_counter_sent_data_to_pc =0U;
		  ui8_printer_status =0;


		  if(my_var_user.ui8_need_reset_device ==1U)
		  {
			  if (HAL_GetTick() > my_var_user.ui32_timer_reset_device)
			  {
				  my_var_user.ui8_need_reset_device =0U;
				  USBD_UsrLog("----------System reboost-----------------------------------------------------.");
				  System_Reboot();
			  }
		  }
	  }

//	  xuly_data_print();
	  xuly_data_print_itx();
	  inmainstatus();
	  send_satatus();
	  check_snifff();

	  if (quanlyESP.newpagkage ==1)
	  {
		  quanlyESP.newpagkage =0;

//		  xuly_command_ESP();
	  }
	  else if (quanlyESP.newcmd ==1)
	  {
		  quanlyESP.newcmd =0;
		  xuly_package_ESP();
	  }

//	  process_data_to_ESP();
//	  test_tx_it();

	  /* USER CODE END WHILE */
    MX_USB_HOST_Process();

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  /*25 MHZ*/

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 20;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 5;

  /* internal osc*/
  /*
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 13;
  RCC_OscInitStruct.PLL.PLLN = 195;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 5;
*/


  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart1.Instance = UART2ESP32;
//  huart1.Init.BaudRate = 230400;
  //  huart1.Init.BaudRate = 1666666;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, Printer_Enable_Pin|GPIO_PIN_0|RS232_En1_Pin|RS232_En2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, LedUSB_B_Pin|LedData_Pin|LedSys_Pin|LedUSB_A_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
    HAL_GPIO_WritePin(GPIOE, CTR_RS232_POWER_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Printer_Enable_Pin PC0 */
  GPIO_InitStruct.Pin = Printer_Enable_Pin|GPIO_PIN_0|RS232_En1_Pin|RS232_En2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LedUSB_B_Pin LedData_Pin LedSys_Pin LedUSB_A_Pin */
  GPIO_InitStruct.Pin = LedUSB_B_Pin|LedData_Pin|LedSys_Pin|LedUSB_A_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : */
  GPIO_InitStruct.Pin = CTR_RS232_POWER_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/**
* @brief  The function informs user that data have been received
*  @param  pdev: Selected device
* @retval None
*/
void USBH_CDC_TransmitCallback(USBH_HandleTypeDef *phost)
{
	/* in debug */

	if (phost->user_status_send_data ==USBH_URB_STALL)
	{
		if(phost->user_status_send_data_old != phost->user_status_send_data)
		{
//			USBH_UsrLog(" !!urb_stall");
			quanlytruyendata.txtorealdevice = 2U;
//			ready_to_received_data();
		}
	}
	else if (phost->user_status_send_data == USBH_URB_NOTREADY)
	{
		if(phost->user_status_send_data_old != phost->user_status_send_data)
		{
//			USBH_UsrLog("USBH_URB_NOTREADY @ %d",user_manage_request.request_dang_thuc_thi);
		}
		/* chưa sẵn sàng nhận data */
	}
	else
	{
		quanlytruyendata.txtorealdevice = 1U;
		/* sẵn sàng nhận data tiếp theo */
/*		1-là mở chỗ này
		2 là mở trong hàm CDC_Receive_HS: dòng 510*/

		pcommand->need_getreadyrx =0U;
		ready_to_received_data();
	}

	/* lưu trạng thái cuối */
	phost->user_status_send_data_old = phost->user_status_send_data;

	/* xóa trạng thái mới */
	phost->user_status_send_data =0U;
}


void USBH_CDC_ReceiveCallback(USBH_HandleTypeDef *phost)
{
	int len = USBH_CDC_GetLastReceivedDataSize(phost);


	/*debug data start*/
	if(len > 0)
	{
		USER_Log_NOCRLF("Data from device: @len = %d : ", len);
		for (int i =0; i<len; i++)
		{
			USER_Log_NOCRLF("%x",PRINTER_RX_Buffer[i]);
			USER_Log_NOCRLF(" ");
		}
		USER_Log_NOCRLF("\n");

	}
	/*debug data end*/

	/*thông báo có data từ real device*/
	quanlytruyendata.codataturealdevice =1U;
	quanlytruyendata.chieudaidatarealdevice = len;
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
  /* NOTE: This function should not be modified, when the callback is needed,
           the HAL_UART_TxCpltCallback could be implemented in the user file
   */
  quanlyESP.status_tx_datruyenxong = 1;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
//	UNUSED(huart);

//	#data$
 if(huart->Instance == USART1)
 {

/*xử lý nhận uart theo gói*/
	 	 uint8_t inchar = quanlyESP.RX_buf[0];

	 	if (quanlyESP.busy == 0)
	 	{
			 if(inchar =='#')
			{
				quanlyESP.RX=1;
				quanlyESP.index_uarrt =0;
			}

			if(quanlyESP.RX ==1)
			{
					quanlyESP.str[quanlyESP.index_uarrt]=inchar;
					quanlyESP.index_uarrt++;

					if (quanlyESP.index_uarrt > MAX_BUFFER_CMD_ESP -1 )
					{
						/*tràn buffer*/
						quanlyESP.RX=0;
						quanlyESP.index_uarrt =0;
					}
					if (inchar =='$')
					{
						quanlyESP.newcmd =1;
						quanlyESP.RX=0;
						quanlyESP.busy =1;
					}
			}
			else
			{
				quanlyESP.newpagkage =1;
				quanlyESP.newinchar=inchar;
			}
	 	}

		HAL_UART_Receive_IT(&huart1, quanlyESP.RX_buf,1);
 }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
