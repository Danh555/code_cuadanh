/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define DF_SERIAL_TO_SERVER 1U

/* định dạng phần cứng */
#define HWVS_TYPE0		0	/*	hardware đầu tiên: đang demo bên Sing */
#define HWVS_TYPE1		1	/*	phiên bản có cổng USB, serial...không có ROM ngoài, chip STM32F205VGT 1M */
#define HWVS_TYPE2		2	/*	phiên bản có cổng USB, serial...không có ROM ngoài, chip STM32F205VET 256k */
#define HWVS_TYPE3		3   /*	phiên bản có cổng USB, serial...có ROM ngoài, chip STM32F205VGT 1M */

/* định dạng máy in */
#define TM_T88IV		1U
#define TM_T82II		2U
//#define TM_T82X		3U
#define TM_T81			3U	/* phiên bản chạy demo bên Sing chạy được cho các dòng Epson khác */
#define TM_UNKNOW		4U


/* config phần cứng */
//VERSION_NAME = HWVERSION.PRINTER_MODEL.RELEASEVS

#define HWVERSION			HWVS_TYPE3
#define PRINTER_MODEL		TM_UNKNOW
#define RELEASEVS			4


#define chip256k 1
#define chip1M	2

#if (HWVERSION == HWVS_TYPE1 || HWVERSION == HWVS_TYPE3)
	#define usingchip chip1M
#else
	#define usingchip chip256k
#endif


/* các biến dùng debug code */
#define DEBUG_NO_ERASER_FLASH 0U
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
typedef struct
{
  uint8_t	Cmddata[20];
  uint8_t	CmdOpCode;
  uint16_t	CmdLength;
}
MY_CMD_TypeDef;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
/*----------   -----------*/
#define MY_USB_DEV		1U
/* 5x200 */

#define MAX_USER_GET_USB_DATA		6U
/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
#define HW_V1 1
#define HW_V2 2

#define HW HW_V2



/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#if (HW == HW_V1)
	#define Printer_Enable_Pin GPIO_PIN_14
	#define Printer_Enable_GPIO_Port GPIOC
	#define LedUSB_B_Pin GPIO_PIN_11
	#define LedUSB_B_GPIO_Port GPIOD
	#define LedData_Pin GPIO_PIN_12
	#define LedData_GPIO_Port GPIOD
	#define LedSys_Pin GPIO_PIN_13
	#define LedSys_GPIO_Port GPIOD
	#define LedUSB_A_Pin GPIO_PIN_14
	#define LedUSB_A_GPIO_Port GPIOD
	#define UART2ESP32 UART5
#else

	/* khai báo cho board điều khiển mới Nov302023 */

	#define Printer_Enable_Pin GPIO_PIN_14
	#define Printer_Enable_GPIO_Port GPIOC
	#define LedUSB_B_Pin GPIO_PIN_11
	#define LedUSB_B_GPIO_Port GPIOD
	#define LedData_Pin GPIO_PIN_12
	#define LedData_GPIO_Port GPIOD
	#define LedSys_Pin GPIO_PIN_14
	#define LedSys_GPIO_Port GPIOD

	#define LedUSB_A_Pin GPIO_PIN_13
	#define LedUSB_A_GPIO_Port GPIOD
	#define RS232_En1_Pin GPIO_PIN_4
	#define RS232_En1_GPIO_Port GPIOC
	#define RS232_En2_Pin GPIO_PIN_5
	#define RS232_En2_GPIO_Port GPIOC

	#define CTR_RS232_POWER_Pin GPIO_PIN_11
	#define CTR_RS232_POWER_GPIO_Port GPIOE

	//thay đổi uart nhớ chỉnh trong đây HAL_UART_MspInit
	#define UART2ESP32 USART1
	#define UART_DEBUG UART5


#endif


/* USER CODE BEGIN Private defines */

#define MAX_USER_GET_USB_REQUEST 128	/* bộ đệm chứa request từ PC, =15U đang ok */
#define MAX_USER_GET_PRINTED_PKG 5U /* 5U */
#define BUFFER_PRINTING 2U /* nhận mỗi gói 4096*//* set bằng 2 không dùng tới gói này*/
#define BUFFER_TX_SERVER_SIZE 2048 /* mỗi lần truyền gói qua server*/

#define MAX_REQUEST_RX_PAUSE 10	/* nếu nhận quá số này, thì dừng không nhận nữa */
#define MAX_REQUEST_RX_RESTART 1	/* reset lại để nhận data từ PC */

#define MAX_BUFFER_TX_SIZE 4096 /* chứa data truyền qua ESP */

/* --------------------------thông số lưu trong flash-------------------------------------------*/
/* Headder: 40 byte chứa thông tin chung
 * word 1: total of package
 * word 2: length of package 1
 * word 3: length of package 2
 * ..
 * word 10: length of package 9
 * */

#if (usingchip == chip1M)
	#define MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME 2	/*  */
#else
	#define MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME 1	/*  */
#endif

#define FLASH_USER_HEADDER_ADDR ((uint32_t)0x08020000)
#define FLASH_USER_START_ADDR ((uint32_t)0x08020028)

/* vùng 2 */
#define FLASH_USER_HEADDER_ADDR2 ((uint32_t)0x080A0000)
#define FLASH_USER_START_ADDR2 ((uint32_t)0x080A0028)
/* --------------------------thông số lưu trong flash-------------------------------------------*/

typedef enum
{
  USER_TYPE_CONTROL   = 0U,
  USER_TYPE_DATA,
  USER_TYPE_PRINTED,
} USER_RequestTypeDef;

typedef enum
{
	DEBUG_BUSY =0U,
	DEBUG_OK,
} USER_DebugTypeDef;

typedef enum {
  ESP_STATE_SETUP = 0,
  ESP_SEND,
  ESP_WAITSEND,
  ESP_INIT,
  ESP_WAIT_ESPIDLE,
  ESP_NEXT_PKG,
  ESP_RECEIVE,
}ESP_StateTypedef;

typedef struct _USER_REQUESET_TypeDef
{
	uint8_t		noidung_loai_request;	/* CONTROL, DATA */
	uint8_t		noidung_chieudaicontrol;/* chứa chiều dài data control*/
	uint8_t		noidung_data[65];	/* chứa data nhận được 65*/
	uint16_t 	noidung_chieudai;	/* chiều dài của data nhận được */
}
USER_REQUESET_TypeDef;

typedef struct _USER_DATA_PRINT_TypeDef
{
	uint8_t		print_data[BUFFER_PRINTING +2];	/* chứa data nhận được*/
	uint16_t	print_length;	/* chứa data nhận được*/
}
USER_DATA_PRINT_TypeDef;

typedef struct
{
  uint16_t                 dataprint_tonglenh;/* số lượng gói data in trong buffer*/
  uint16_t                 dataprint_doing;/* đang in tới gói data này*/
  uint16_t                 print_length_tam;/* chiều dài gói data đang nhận vào*/
  uint16_t                 request_tong_nhan;
  uint16_t                 request_dang_thuc_thi;
  uint16_t                 request_tx_to_esp;	/* đang truyền qua esp */
  uint16_t                 need_getreadyrx;/* =1: cần gọi hàm sẵn sàng nhận data*/
  uint32_t                 data_print_size;/* tổng kích thước file in*/
  uint32_t                 u32_addr_data_store;/* */
  uint32_t                 u32_addr_header_store;/* */
  uint8_t                  ui8_startprint;
  uint8_t                  ui8_printing;/* thông báo đang nhận data in*/
  uint8_t                  WAIT_SEND_TO_SERVER;/* =1U: chờ truyền qua ESP xong mới kích hoạt lại nhận data */
  uint8_t                  chophepluu;
  uint8_t                  ui8_countzlp;
  uint8_t                  duocphepdebug;/* =1U: được phép debug serial, =0U: busy: đang truyền data qua server chip*/

  /* quản lý lưu data vào flash */
  uint8_t                  number_printed; /* số file trong hàng đợi */
  uint8_t                  number_printed_processing; /* file đang xử lý */
  uint32_t                 package_index; /* chứa từng đoạn gói dữ liệu in */
  uint32_t				   chieudaitungfile[10]; /* chiều dài tương ứng đoạn dữ liệu in */

  /* quản lý sniffer log*/
  uint8_t                  chophepsniff;
  uint8_t                  readytopausesniff;
  uint32_t					timer_pausesniff;


  USER_REQUESET_TypeDef	  request_noidung[MAX_USER_GET_USB_REQUEST];
  USER_DATA_PRINT_TypeDef print_noidung[MAX_USER_GET_PRINTED_PKG];
}USER_TypeDef;	/*	user_manage_request	pcommand */

typedef struct
{
	  uint8_t			ui8_need_reinint;/* nếu có kết nối từ real device-->khởi tạo kết nối Virtual_Device */
	  uint8_t			ui8_user_forward_state;
	  uint8_t 			ui8_chophep_docdata_tu_realdevice;	/* class FF: lệnh điều khiển clear feature*/
	  uint16_t 			ui16_interval;	/* dùng để kiểm tra interupt usb type */
//	  uint8_t 			ui8_thongbao_ketnoiapp;				/* thông báo có data nhận được từ Host PC tới Virtual_Device */
	  uint8_t 			ui8_need_reinint_Virtual_Device; /* nếu có kết nối từ real device-->khởi tạo kết nối Virtual_Device */
	  uint16_t 			ui16_counterbusy; /*  */
	  uint8_t 			datafromdevice[50]; /*  */
	  uint8_t 			ui8_status_esp;
	  uint8_t 			ui8_finished_printer;
	  uint32_t 			u32_addr_data_user;
	  uint32_t 			ui32_txprinterlength;
	  uint32_t 			ui32_timerxset;
	  uint32_t 			ui32_counter_send_status;
	  uint32_t 			lentosend;
	  uint8_t 			ui8_package_tx;
	  uint8_t 			ui8_printer_status;/* =1: đã kết nối máy in thành công, =0 erro*/
	  uint8_t 			ui8_counterflashled;/* */
	  uint8_t 			ui8_statusled;/* */
	  uint32_t 			ui32_timer_reset_device;/* thời gian cần reset lại thiết bị, nếu có máy in gắn vào, mà không thể khởi tạo kết nối với máy in được*/
	  uint8_t 			ui8_need_reset_device; /* =1: cần reset lại thiết bị, nếu có máy in gắn vào, mà không thể khởi tạo kết nối với máy in được*/

}USER_cacbien_chung_TypeDef;	/* my_var_user */

typedef struct
{
	  uint8_t 			txtorealdevice; 	/* =1  đã truyền và có phản hồi, =0 đang truyền , =2: có lỗi truyền */
	  uint16_t 			timeouttxtodevice;
	  uint32_t 			time_wait_next_print_pck; 	/* =1  đã truyền và có phản hồi, =0 đang truyền */
	  uint32_t 			timesend;
	  uint8_t			batdauin; /* =1: bắt đầu thực hiện chuyển gói in qua printer*/
	  uint8_t			printer_period; /* giai đoạn chuyển tiếp data printed qua máy in*/
	  uint8_t 			codataturealdevice; /* =1U: có data từ real device */
	  uint16_t 			chieudaidatarealdevice; /*  */
	  uint16_t 			counter_sent_data_to_pc; /*  */
	  uint8_t 			index_truyenlenpc; /*  */
	  uint32_t 			timer_syncdata; /* class FF: lệnh điều khiển clear feature*/
	  uint8_t			check_data_index;

}USER_cacbien_chung2_TypeDef;

typedef struct
{
		uint16_t 		counter;
		uint32_t 		u32_timeout;
		uint32_t 		u32_meas;
		uint8_t 		bien1;

}USER_cacbien_dungdebug_code_TypeDef;

//USER_cacbien_dungdebug_code_TypeDef biendebug_code;

#define MAX_BUFFER_CMD_ESP 20
typedef struct
{
	/*nhận data*/
	uint8_t 			RX_buf[2];	/* buffer tạm */
	uint8_t 			str[MAX_BUFFER_CMD_ESP];	/* chứa chuỗi nhận được */
	uint8_t 			busy;	/*=1: đang xử lý gói data */
	uint8_t 			newinchar;	/*data mới nhất*/
	uint8_t 			RX;
	uint8_t 			index_uarrt;
	uint8_t 			newpagkage;
	uint8_t 			newcmd;	/*=1 nhận theo gói từ uart*/

	/*truyền data*/
	uint8_t 			indextx;
	uint8_t 			status_tx_datruyenxong;/* =1: đã truyền xong */
	uint8_t 			status_tx_dangtruyen;
	uint16_t 			ui16_vitridoctin;
	uint16_t 			ui16_vitriluutin;
	uint16_t 			cmd_tx; /* =1: có data để truyền */
	uint16_t 			lentx;
	uint16_t 			index_pkg;
	uint8_t 			datatosend[MAX_BUFFER_TX_SIZE];

}USER_cacbien_truyenquaESP_TypeDef;


//USER_cacbien_truyenquaESP_TypeDef quanlyESP;

#if (DF_SERIAL_TO_SERVER > 0)
#define SERIAL_TO_SERVER(...)    printf(__VA_ARGS__);\
								 printf("\n");
#else
#define SERIAL_TO_SERVER(...)
#endif

#define USER_Log_NOCRLF(...)    printf(__VA_ARGS__);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
