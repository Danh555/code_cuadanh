/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_cdc_if.c
  * @version        : v1.0_Cube
  * @brief          : Usb device for Virtual Com Port.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_cdc_if.h"

/* USER CODE BEGIN INCLUDE */
#include "usb_host.h"
#include "usbh_cdc.h"
extern USBH_HandleTypeDef hUsbHostFS;
//extern MY_CMD_TypeDef request_manager[MAX_USER_GET_USB_REQUEST];
/* USER CODE END INCLUDE */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
extern UART_HandleTypeDef huart1;
uint8_t buffer[7];
//extern uint8_t request_Buffer[MAX_USER_GET_USB_REQUEST][20];
extern uint8_t request_index;

//extern uint8_t mydataprint_Buffer[MAX_USER_GET_USB_DATA][4096];
extern volatile uint8_t dataprint_doing;
volatile uint8_t data_index = 0U;


/* USER CODE END PV */

/** @addtogroup STM32_USB_OTG_DEVICE_LIBRARY
  * @brief Usb device library.
  * @{
  */

/** @addtogroup USBD_CDC_IF
  * @{
  */

/** @defgroup USBD_CDC_IF_Private_TypesDefinitions USBD_CDC_IF_Private_TypesDefinitions
  * @brief Private types.
  * @{
  */

/* USER CODE BEGIN PRIVATE_TYPES */

/* USER CODE END PRIVATE_TYPES */

/**
  * @}
  */

/** @defgroup USBD_CDC_IF_Private_Defines USBD_CDC_IF_Private_Defines
  * @brief Private defines.
  * @{
  */

/* USER CODE BEGIN PRIVATE_DEFINES */
/* USER CODE END PRIVATE_DEFINES */

/**
  * @}
  */

/** @defgroup USBD_CDC_IF_Private_Macros USBD_CDC_IF_Private_Macros
  * @brief Private macros.
  * @{
  */

/* USER CODE BEGIN PRIVATE_MACRO */

/* USER CODE END PRIVATE_MACRO */

/**
  * @}
  */

/** @defgroup USBD_CDC_IF_Private_Variables USBD_CDC_IF_Private_Variables
  * @brief Private variables.
  * @{
  */

/* Create buffer for reception and transmission           */
/* It's up to user to redefine and/or remove those define */
/** Received data over USB are stored in this buffer      */
uint8_t UserRxBufferHS[APP_RX_DATA_SIZE];

/** Data to send over USB CDC are stored in this buffer   */
uint8_t UserTxBufferHS[APP_TX_DATA_SIZE];

/* USER CODE BEGIN PRIVATE_VARIABLES */

/* USER CODE END PRIVATE_VARIABLES */

/**
  * @}
  */

/** @defgroup USBD_CDC_IF_Exported_Variables USBD_CDC_IF_Exported_Variables
  * @brief Public variables.
  * @{
  */

extern USBD_HandleTypeDef hUsbDeviceHS;

/* USER CODE BEGIN EXPORTED_VARIABLES */

/* USER CODE END EXPORTED_VARIABLES */

/**
  * @}
  */

/** @defgroup USBD_CDC_IF_Private_FunctionPrototypes USBD_CDC_IF_Private_FunctionPrototypes
  * @brief Private functions declaration.
  * @{
  */

static int8_t CDC_Init_HS(void);
static int8_t CDC_DeInit_HS(void);
static int8_t CDC_Control_HS(uint8_t cmd, uint8_t* pbuf, uint16_t length);
static int8_t CDC_Receive_HS(uint8_t* pbuf, uint32_t *Len);

/* USER CODE BEGIN PRIVATE_FUNCTIONS_DECLARATION */

/* USER CODE END PRIVATE_FUNCTIONS_DECLARATION */

/**
  * @}
  */

USBD_CDC_ItfTypeDef USBD_Interface_fops_HS =
{
  CDC_Init_HS,
  CDC_DeInit_HS,
  CDC_Control_HS,
  CDC_Receive_HS
};

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Initializes the CDC media low layer over the USB HS IP
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CDC_Init_HS(void)
{
  /* USER CODE BEGIN 8 */
  /* Set Application Buffers */
  USBD_CDC_SetTxBuffer(&hUsbDeviceHS, UserTxBufferHS, 0);
  USBD_CDC_SetRxBuffer(&hUsbDeviceHS, UserRxBufferHS);
  return (USBD_OK);
  /* USER CODE END 8 */
}

/**
  * @brief  DeInitializes the CDC media low layer
  * @param  None
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CDC_DeInit_HS(void)
{
  /* USER CODE BEGIN 9 */
  return (USBD_OK);
  /* USER CODE END 9 */
}

/**
  * @brief  Manage the CDC class requests
  * @param  cmd: Command code
  * @param  pbuf: Buffer containing command data (request parameters)
  * @param  length: Number of data to be sent (in bytes)
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CDC_Control_HS(uint8_t cmd, uint8_t* pbuf, uint16_t length)
{
	/* USER CODE BEGIN 10 */
	#if (0)
		USBD_UsrLog("control = %x, len = %x", cmd, length)

		if( length >0U)
		{
			USBD_UsrLogCog(" \t data control = ");
			for(int i =0; i< length; i++)
			{
				USBD_UsrLogCog(" %02x", pbuf[i]);
			}
			USBD_UsrLogCog("\n");
		}
	#endif

		/* copy data control */
		if(length > 0)
		{
			USER_REQUESET_TypeDef *pmydata;
			int vitriluutin = pcommand->request_tong_nhan % MAX_USER_GET_USB_REQUEST;
			pmydata =&pcommand->request_noidung[vitriluutin];

			for (int i=0;i<length;i++)
			{
				pmydata->noidung_data[8+i]=pbuf[i];/* 8 byte đầu là request, byte thứ 9 là data control */
			}

		//	pmydata->noidung_loai_request = USER_TYPE_DATA;
			pmydata->noidung_chieudaicontrol = length;
			pcommand->request_tong_nhan++;


	/*		if (cmd ==0x20)
			{
				USBD_UsrLogCog(" \t data request = ");
				for(int i =0; i< length+8; i++)
				{
					USBD_UsrLogCog(" %02x", pmydata->noidung_data[i]);
				}
				USBD_UsrLogCog("\n");
			}*/
		}
		/* copy data control */

		return (USBD_OK); /* Congthem : không quan tâm nó điều khiển gì: chuyển tín hiệu này qua printer: Real device */

	  switch(cmd)
	  {
	  case CDC_SEND_ENCAPSULATED_COMMAND:

	    break;

	  case CDC_GET_ENCAPSULATED_RESPONSE:

	    break;

	  case CDC_SET_COMM_FEATURE:

	    break;

	  case CDC_GET_COMM_FEATURE:

	    break;

	  case CDC_CLEAR_COMM_FEATURE:

	    break;

	  /*******************************************************************************/
	  /* Line Coding Structure                                                       */
	  /*-----------------------------------------------------------------------------*/
	  /* Offset | Field       | Size | Value  | Description                          */
	  /* 0      | dwDTERate   |   4  | Number |Data terminal rate, in bits per second*/
	  /* 4      | bCharFormat |   1  | Number | Stop bits                            */
	  /*                                        0 - 1 Stop bit                       */
	  /*                                        1 - 1.5 Stop bits                    */
	  /*                                        2 - 2 Stop bits                      */
	  /* 5      | bParityType |  1   | Number | Parity                               */
	  /*                                        0 - None                             */
	  /*                                        1 - Odd                              */
	  /*                                        2 - Even                             */
	  /*                                        3 - Mark                             */
	  /*                                        4 - Space                            */
	  /* 6      | bDataBits  |   1   | Number Data bits (5, 6, 7, 8 or 16).          */
	  /*******************************************************************************/
	  case CDC_SET_LINE_CODING:
			buffer[0]=pbuf[0];
			buffer[1]=pbuf[1];
			buffer[2]=pbuf[2];
			buffer[3]=pbuf[3];
			buffer[4]=pbuf[4];
			buffer[5]=pbuf[5];
			buffer[6]=pbuf[6];
	    break;

	  case CDC_GET_LINE_CODING:
		  pbuf[0]=buffer[0];
		  pbuf[1]=buffer[1];
		  pbuf[2]=buffer[2];
		  pbuf[3]=buffer[3];
		  pbuf[4]=buffer[4];
		  pbuf[5]=buffer[5];
		  pbuf[6]=buffer[6];
	    break;

	  case CDC_SET_CONTROL_LINE_STATE:

	    break;

	  case CDC_SEND_BREAK:

	    break;

	  default:
	    break;
	  }

	  return (USBD_OK);
	  /* USER CODE END 10 */
}

static int8_t USER_SNIFFER_LOG(uint8_t* Buf, uint32_t *Len)
{
	uint16_t len = *Len;
	if (len > 0U && len < 64U)
	{
		USBD_UsrLog("Data from PC: ");

		USBD_UsrLogCog(" len = %d : ", len);
		for (int i =0; i<len; i++)
		{
		  USBD_UsrLogCog(" %02x", Buf[i]);
		}
		USBD_UsrLogCog("\n");
	}
	else if (len > 64U )
	{
		USBD_UsrLog("warning !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

		USBD_UsrLogCog(" len = %d", len);
		for (int i =0; i<len; i++)
		{
		  USBD_UsrLogCog(" %02x", Buf[i]);
		}
		USBD_UsrLogCog("\n");
	}

//	 khởi tạo giá trị
	if(pcommand->chophepsniff ==1U)
	{
		 /* thiết lập nhận data pringting */

		 int vitridoctin = pcommand->number_printed % MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME;

		 if(vitridoctin ==1)
		 {
			 pcommand->u32_addr_data_store = FLASH_USER_START_ADDR2;
			 pcommand->u32_addr_header_store =FLASH_USER_HEADDER_ADDR2;
		 }
		 else
		 {
			 pcommand->u32_addr_data_store = FLASH_USER_START_ADDR;
			 pcommand->u32_addr_header_store =FLASH_USER_HEADDER_ADDR;
		 }

		 pcommand->data_print_size =0; //reset size
		 pcommand->chophepsniff =2U;
	}

	//lưu vào vùng flash
	if(pcommand->chophepsniff ==2U && len > 0U)
	{
		int numofwords = (len/4)+((len%4)!=0);
		uint16_t myRxDataLength = numofwords*4;


//		lưu chiều dài

		uint32_t j = (uint32_t)len;
		Flash_Write_Data(pcommand->u32_addr_data_store, &j, 1U);

//		USBD_UsrLogCog("save @ %x =  %d", pcommand->u32_addr_data_store, len);

		pcommand->u32_addr_data_store += 4;
		pcommand->data_print_size += 4;

//		lưu data
		Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)Buf, numofwords);

//		cập nhật chiều dài tổng
		pcommand->data_print_size +=myRxDataLength;

		pcommand->u32_addr_data_store +=myRxDataLength;

		// kiểm tra điều kiện dừng tự động: timeout / đủ kích thước qui định....
		if (pcommand->data_print_size > 1024)
		{
			pcommand->readytopausesniff =1U;
		}
//		reset timer
		pcommand->timer_pausesniff = HAL_GetTick();

	}

}
/**
  * @brief  Data received over USB OUT endpoint are sent over CDC interface
  *         through this function.
  *
  *         @note
  *         This function will issue a NAK packet on any OUT packet received on
  *         USB endpoint until exiting this function. If you exit this function
  *         before transfer is complete on CDC interface (ie. using DMA controller)
  *         it will result in receiving more data while previous ones are still
  *         not sent.
  *
  * @param  Buf: Buffer of data to be received
  * @param  Len: Number of data received (in bytes)
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  *
  * @MrCong Hàm nhận data từ PC ( from USBD_CDC_DataOut\Receive)
  */
static int8_t CDC_Receive_HS(uint8_t* Buf, uint32_t *Len)
{
	/* USER CODE BEGIN 11 */
		static int vitriluutin;
		static int vitriluudata;
		uint16_t len = *Len;

		USER_DATA_PRINT_TypeDef *saveprint;
		vitriluudata = pcommand->dataprint_tonglenh % MAX_USER_GET_PRINTED_PKG;
		saveprint =&pcommand->print_noidung[vitriluudata];

		uint16_t myRxDataLength = pcommand->print_length_tam;


		if (pcommand->need_getreadyrx)
		{
			USBD_UsrLog("\n----------Busy busy---------------- \n");
			return (USBD_BUSY);
		}
#if (0)
		if (len > 0U && len < 64U)
		{
			USBD_UsrLog("Data from PC: ");

			USBD_UsrLogCog(" len = %d : ", len);
			for (int i =0; i<len; i++)
			{
			  USBD_UsrLogCog(" %02x", Buf[i]);
			}
			USBD_UsrLogCog("\n");
		}
		else if (len > 64U )
		{
			USBD_UsrLog("warning !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

			USBD_UsrLogCog(" len = %d : index =%d", len, vitriluutin);
			for (int i =0; i<len; i++)
			{
			  USBD_UsrLogCog(" %02x", Buf[i]);
			}
			USBD_UsrLogCog("\n");
		}

#endif

		/* --------------- start copy vào buffer de truyền qua máy in -------------------------------------*/
		USER_REQUESET_TypeDef *pmydata;
		vitriluutin = pcommand->request_tong_nhan % MAX_USER_GET_USB_REQUEST;
		pmydata =&pcommand->request_noidung[vitriluutin];

		for (int i=0;i<len;i++)
		{
			pmydata->noidung_data[i]=Buf[i];
		}

		pmydata->noidung_loai_request = USER_TYPE_DATA;
		pmydata->noidung_chieudai = len;
		pmydata->noidung_chieudaicontrol = 0U;
		pcommand->request_tong_nhan++;

		/* --------------- end copy vào buffer de truyền qua máy in -------------------------------------*/


		/* --------------- so sánh để tạo sniffer log -------------------------------------*/


		if(pcommand->chophepsniff > 0U)
		{
			USER_SNIFFER_LOG(Buf, Len);
			return (USBD_OK);
		}

		/* --------------- start so sanh de xu ly -------------------------------------*/

		uint8_t sosanhlenh =0;


		//tìm lệnh bắt đầu in

#if (PRINTER_MODEL == TM_T82II)
		if(len ==6U)
		{
			/* bắt đầu in */
			 /*
				 TM-T82X:
				 TM-T82II:	1b 3d 1 1d 49 1
				 TM-T88IV:	1b 3d 1 1d 49 1
			 */
			 if (Buf[0] == 0x1bU && Buf[1] == 0x3dU && Buf[2] == 0x01U && Buf[3] == 0x1dU && Buf[4] == 0x49U && Buf[5] == 0x01U)
			 {
				 sosanhlenh =1;
			 }
		}
		else if (len == 11U)
		 {
			 /*  Kết thúc in */
			 /*
				 TM-T82X:	1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a 00 1d 56 41
				 TM-T82II:	1D 28 48 06 00 30 30 20 20 20 4F
				 TM-T88IV:	1d 28 48 06 00 30 30 20 20 22 28
			 */
			 if (Buf[0] == 0x1dU && Buf[1] == 0x28U && Buf[2] == 0x48U && Buf[3] == 0x06U && Buf[4] == 0x00U)
			 {
				 sosanhlenh =2;
			 }
		 }
#elif (PRINTER_MODEL == TM_T82X)

		if(pcommand->ui8_startprint ==0U)
		{
			//tìm điểm bắt đầu in
			 /*
				 TM-T82X:
				 len =???
				 1B 3D 01 1D 28 4A 02 00 01 00 1D 28 4A 02 00 02 00 1D

			 */

			 if (Buf[0] == 0x1bU && Buf[1] == 0x3dU && Buf[2] == 0x01U && Buf[3] == 0x1dU && Buf[4] == 0x28U && Buf[5] == 0x4AU)
			 {
				 sosanhlenh =1;
			 }

		}
		else
		{
			//tìm điểm kết thúc in
			/*
			 len end = ...
			 01 0A AB 2E
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00

			 len end = 0x14:
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00

			 len end = 61: 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
			 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1

			 len end = 19:
			 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
			 */

			if (len == 19U)
			 {
				 /*  Kết thúc in */
				 /*
					 TM-T82X:

					 ghi chú: nhận 2-3 gói kết thúc

					 gói cuối
					 len =, data:
					 FA FC 12 38 FD F0 1F 01 0A AB 2E
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1

					 len =19
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1



					 len = 62, data:
					 70 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
					 --> có chứa gói kết thúc 19 byte nằm trong gói kết thúc cuối

					 len = 19
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1


				 */
				 if (Buf[0] == 0x1dU && Buf[1] == 0x28U && Buf[2] == 0x4CU && Buf[3] == 0x02U && Buf[4] == 0x00U)
				 {
					 sosanhlenh =2;
				 }
			 }
			else if (len > 0U)
			 {
				 /*  Kết thúc in */
				 /*
					 TM-T82X:

					 ghi chú: nhận 2-3 gói kết thúc

					 gói cuối
					 len =, data:
					 FA FC 12 38 FD F0 1F 01 0A AB 2E
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1

					 len =19
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1



					 len = 62, data:
					 70 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
					 --> có chứa gói kết thúc 19 byte nằm trong gói kết thúc cuối

					 len = 19
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1

				 */
				 if (Buf[len -3] == 0x1bU && Buf[len -2] == 0x4aU && Buf[len -1] == 0xC1U)
				 {
					 sosanhlenh =2;
					 //chú ý: đây là gói bao gồm cả data khúc cuối, nên cần lưu gói này lại luôn


					 myRxDataLength = len;
					 pcommand->data_print_size +=myRxDataLength;
					 int numofwords = (myRxDataLength/4)+((myRxDataLength%4)!=0);
					Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, numofwords);
					pcommand->u32_addr_data_store +=myRxDataLength;

				 }
			 }
		}

#elif (PRINTER_MODEL == TM_T81 || PRINTER_MODEL == TM_T88IV)

		if(pcommand->ui8_startprint ==0U)
		{
			//tìm điểm bắt đầu in
			 /*
				 TM-T82X:
				 len =???
				 1B 3D 01 1D 28 4A 02 00 01 00 1D 28 4A 02 00 02 00 1D

			 */


			if(len ==6U)
			{
				/* bắt đầu in */
				 /*
					 TM-T82X:
					 TM-T82II:	1b 3d 1 1d 49 1
					 TM-T88IV:	1b 3d 1 1d 49 1
				 */
				 if (Buf[0] == 0x1bU && Buf[1] == 0x3dU && Buf[2] == 0x01U && Buf[3] == 0x1dU && Buf[4] == 0x49U && Buf[5] == 0x01U)
				 {
					 sosanhlenh =1;
					 USBD_UsrLogCog("\n start print 6\n");
				 }
			}
			else if (len == 64U)

			{
				if (Buf[0] == 0x1bU && Buf[1] == 0x3dU && Buf[2] == 0x01U && len == 64U)
			 {
				 sosanhlenh =1;
				 USBD_UsrLogCog("\n start print 64\n");
			 }
			}


		}
		else
		{
			//tìm điểm kết thúc in
			/*
			 len end = ...
			 01 0A AB 2E
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00

			 len end = 0x14:
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00

			 len end = 61: 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
			 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1

			 len end = 19:
			 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
			 */

			if (len == 11U)
			 {
				 /*  Kết thúc in */
				 /*
					 TM-T82X:

					 ghi chú: nhận 2-3 gói kết thúc

					 gói cuối
					 len =, data:
					 FA FC 12 38 FD F0 1F 01 0A AB 2E
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1

					 len =19
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1



					 len = 62, data:
					 70 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
					 --> có chứa gói kết thúc 19 byte nằm trong gói kết thúc cuối

					 len = 19
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1


				 */
				 if (Buf[0] == 0x1dU && Buf[1] == 0x28U && Buf[2] == 0x48U && Buf[3] == 0x06U && Buf[4] == 0x00U)
				 {
					 sosanhlenh =2;
				 }
			 }
			else if (len > 0U)
			 {
				 /*  Kết thúc in */
				 /*
					 TM-T82X:

					 ghi chú: nhận 2-3 gói kết thúc

					 gói cuối
					 len =, data:
					 FA FC 12 38 FD F0 1F 01 0A AB 2E
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1

					 len =19
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1
					 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A FF 1B 4A C1



					 len = 62, data:
					 70 87 32 8f 87 cd f6 83 eb fc 92 1d 1a b5 f7 93 5f 35 db 0f ae f3 4b b6 a7 67 04 67 c2 d5 f6 c3 fa fc 12 38 fd f0 1f 01 0a ab 2e
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1
					 --> có chứa gói kết thúc 19 byte nằm trong gói kết thúc cuối

					 len = 19
					 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1

					 1B 4A 00 1D 56 41 00

				 */
				 if (Buf[len -3] == 0x1bU && Buf[len -2] == 0x4aU && Buf[len -1] == 0xC1U)
				 {
					 sosanhlenh =2;
					 //chú ý: đây là gói bao gồm cả data khúc cuối, nên cần lưu gói này lại luôn


					 myRxDataLength = len;
					 pcommand->data_print_size +=myRxDataLength;
					 int numofwords = (myRxDataLength/4)+((myRxDataLength%4)!=0);
					Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, numofwords);
					pcommand->u32_addr_data_store +=myRxDataLength;

				 }

				 else if (Buf[len-4] == 0x1dU && Buf[len -3] == 0x56U && Buf[len -2] == 0x41U && Buf[len -1] == 0x00U)
				 {
					 sosanhlenh =2;
					 //chú ý: đây là gói bao gồm cả data khúc cuối, nên cần lưu gói này lại luôn


					 myRxDataLength = len;
					 pcommand->data_print_size +=myRxDataLength;
					 int numofwords = (myRxDataLength/4)+((myRxDataLength%4)!=0);
					Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, numofwords);
					pcommand->u32_addr_data_store +=myRxDataLength;

				 }
			 }
		}
#elif (PRINTER_MODEL == TM_UNKNOW)

		if(pcommand->ui8_startprint ==0U)
		{
			//tìm điểm bắt đầu in
			 /*
				 TM-T82X:
				 len =???
				 1B 3D 01 1D 28 4A 02 00 01 00 1D 28 4A 02 00 02 00 1D

			 */
			if (len == 64U)
			{
				if (Buf[0] != 0x00U)
				{
					sosanhlenh =1;
					USBD_UsrLogCog("\n start print 64\n");
				}
			}
		}
		else
		{
			//tìm điểm kết thúc in
			/*
			 gói in cuối cùng
			 kết thúc bằng các giá trị:

			 TM-T70II---------------------------------------------------
			 ...
			 1D 28 4C 02 00 30 32
			 1B 4A 00
			 1D 56 41 00

			 ...
			 1D 28 4C 02 00 30 32
			 1B 4A 00
			 1B 4A 00
			 1B 4A 00
			 1D 56 41 00

			 len end = 0x14:
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00
			 1D 28 4C 02 00 30 32 1B 4A 00 1B 4A 00 1B 4A 00 1D 56 41 00

			 len end = 61:
			 ...
			 1d 28 4c 02 00 30 32
			 1b 4a 00
			 1b 4a 00
			 1b 4a ff
			 1b 4a c1

			 len end = 19:
			 1d 28 4c 02 00 30 32
			 1b 4a 00
			 1b 4a 00
			 1b 4a ff
			 1b 4a c1

			 TM-T81---------------------------------------------------
			 ...
			 1D 28 4C 02 00 30 32
			 1B 4A 00
			 1D 56 41 00


			 ...
			 1D 28 4C 02 00 30 32
			 1B 4A 00
			 1D 56 41 00

			 TM-T88IV---------------------------------------------------
			 ...
			 1D 28 4E 02 00 30 31
			 1B 4A FF
			 1B 4A AA


			 ...
			 1D 28 4C 02 00 30 32
			 1D 28 4E 02 00 30 31
			 1D 28 4E 02 00 30 31
			 1D 28 4E 02 00 30 31
			 1D 28 4E 02 00 30 31
			 1B 4A 00
			 1D 56 41 00

			 */

			if (len > 0U && len < 64U)
			 {
				/*  Kết thúc in */

				 //chú ý: đây là gói bao gồm cả data khúc cuối, nên cần lưu gói này lại luôn


				/* trường hợp in bill dài:
				 * Epson TM-T88IV sẽ bị chia thành 2 gói: gói 1 là 0x55
				 * các gói sau như bình thường
				 * */
				if (pcommand->data_print_size > 0x64) /* so sánh bỏ qua gói 0x55 */
				{
					sosanhlenh =2;

					myRxDataLength = len;
					 pcommand->data_print_size +=myRxDataLength;
					 int numofwords = (myRxDataLength/4)+((myRxDataLength%4)!=0);
					Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, numofwords);
					pcommand->u32_addr_data_store +=myRxDataLength;


					uint8_t lastindex = pcommand->package_index;
					pcommand->chieudaitungfile[lastindex] = pcommand->data_print_size;
					USBD_UsrLogCog(" save last = %d, len = %ld \n", lastindex, pcommand->chieudaitungfile[lastindex]);

					USBD_UsrLogCog("\n end print 64\n");
				}
			 }
		}
#else
		if(len ==6U)
		{
			/* bắt đầu in */
			 /*
				 TM-T82X:
				 TM-T82II:	1b 3d 1 1d 49 1
				 TM-T88IV:	1b 3d 1 1d 49 1
			 */
			 if (Buf[0] == 0x1bU && Buf[1] == 0x3dU && Buf[2] == 0x01U && Buf[3] == 0x1dU && Buf[4] == 0x49U && Buf[5] == 0x01U)
			 {
				 sosanhlenh =1;
				 USBD_UsrLogCog("\n start print \n");
			 }
		}
		else if (len == 11U)
		 {
			 /*  Kết thúc in */
			 /*
				 TM-T82X:
				 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a 00 1d 56 41
				 1d 28 4c 02 00 30 32 1b 4a 00 1b 4a 00 1b 4a ff 1b 4a c1

				 TM-T82II:	1D 28 48 06 00 30 30 20 20 20 4F
				 TM-T88IV:	1d 28 48 06 00 30 30 20 20 22 28
			 */
			 if (Buf[0] == 0x1dU && Buf[1] == 0x28U && Buf[2] == 0x48U && Buf[3] == 0x06U && Buf[4] == 0x00U)
			 {
				 sosanhlenh =2;
			 }
		 }
#endif

		if(sosanhlenh ==1)
		{
			 //so sánh bộ nhớ trống
			 uint8_t tamnho = pcommand->number_printed - pcommand->number_printed_processing;
			 if (tamnho >= MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME)
			 {
				 sosanhlenh =0;
				 USBD_UsrLogCog("\n reach max printed support \n");
			 }
			 else
			 {
				//bắt đầu in
				 if (pcommand->duocphepdebug ==DEBUG_OK)
				 {
					 USBD_UsrLog("#CMD S1");
				 }

				 /* reset các biến */
				 pcommand->data_print_size = 0U;
				 pcommand->ui8_startprint =1U;
				 pcommand->dataprint_doing =0U;
				 pcommand->dataprint_tonglenh =0U;
				 pcommand->print_length_tam =0U;
				 pcommand->package_index =0U;


				 /* thiết lập nhận data pringting */

				 int vitridoctin = pcommand->number_printed % MAX_USER_PRINTED_SUPPORT_AT_THE_SAME_TIME;

				 if(vitridoctin ==1)
				 {
					 pcommand->u32_addr_data_store = FLASH_USER_START_ADDR2;
					 pcommand->u32_addr_header_store =FLASH_USER_HEADDER_ADDR2;
				 }
				 else
				 {
					 pcommand->u32_addr_data_store = FLASH_USER_START_ADDR;
					 pcommand->u32_addr_header_store =FLASH_USER_HEADDER_ADDR;
				 }
			 }
		}
		else if(sosanhlenh ==2)
		{
			USBD_UsrLogCog(" have end, stt = %x \n", pcommand->ui8_startprint);
			//kết thúc in
			if(pcommand->ui8_startprint == 1U)
			{
				pcommand->ui8_startprint =0U;
				pcommand->ui8_printing =0U;
				 pcommand->WAIT_SEND_TO_SERVER =1U;
				 pcommand->number_printed++;


				 pcommand->package_index++;

				 /* tính tổng gói từ các gói thành phần */
				 uint32_t pp = pcommand->package_index;
				 uint32_t tamlen =0U;
				 uint32_t diachitam = pcommand->u32_addr_header_store;

				 /* save total package */
				 Flash_Write_Data(diachitam, &pcommand->package_index, 1U);
				 USBD_UsrLogCog(" total package = %d \n", pcommand->package_index);

				 diachitam+=4;
				 /* save len package */
				 if (pp ==1U)
				 {
					 USBD_UsrLogCog(" 1 package = %ld \n", pcommand->data_print_size);
					 Flash_Write_Data(diachitam, &pcommand->data_print_size, 1U);
				 }
				 else
				 {
					 for (int k =0; k< pp;k++)
					 {
						 tamlen += pcommand->chieudaitungfile[k];/* get save file*/
						 Flash_Write_Data(diachitam, &pcommand->chieudaitungfile[k], 1U);
						 diachitam += 4;

						 USBD_UsrLogCog(" index = %d, total = %ld \n", k, tamlen);
					 }
				 }
			}

		}
		/* --------------- end so sanh de xu ly -------------------------------------*/


		/* --------------- start copy data vào vùng nhớ -------------------------------------*/

		/* xác định data bắt đầu in */
		if((len == 0x40) && (pcommand->ui8_startprint ==1U))
		{
			pcommand->ui8_printing =1U;
		}

		if (pcommand->ui8_printing ==1U)
		{
			if(len > 0U)
			{
				myRxDataLength =len;
				pcommand->data_print_size +=myRxDataLength;

				/* cập nhật chiều dài file */
				uint8_t indenew = pcommand->package_index;
				pcommand->chieudaitungfile[indenew] = pcommand->data_print_size;

				/*store data to flash */
				int u = len %4;
				if (u)
				{
					u = 4 -u;
					myRxDataLength += u;

					/* lưu chiều dài file 1*/
					uint8_t l = pcommand->package_index;
					pcommand->chieudaitungfile[l] = pcommand->data_print_size;

					USBD_UsrLogCog(" save index = %d, len = %ld \n", l, pcommand->chieudaitungfile[l]);

					pcommand->data_print_size =0U;
					pcommand->package_index++;
				}

				int numofwords = (myRxDataLength/4)+((myRxDataLength%4)!=0);
				Flash_Write_Data(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, numofwords);

//				Flash_Write_byte(pcommand->u32_addr_data_store, (uint32_t *)pmydata->noidung_data, myRxDataLength);

				pcommand->u32_addr_data_store +=myRxDataLength;
//				pcommand->data_print_size +=myRxDataLength;
			}
		}
		/* --------------- end copy data vào vùng nhớ -------------------------------------*/

		/* kiểm tra điều kiện sẵn sàng nhận gói tiếp theo*/
	  return (USBD_OK);
	  /* USER CODE END 11 */
}

/**
  * @brief  Data to send over USB IN endpoint are sent over CDC interface
  *         through this function.
  * @param  Buf: Buffer of data to be sent
  * @param  Len: Number of data to be sent (in bytes)
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL or USBD_BUSY
  */
uint8_t CDC_Transmit_HS(uint8_t* Buf, uint16_t Len)
{
  uint8_t result = USBD_OK;
  /* USER CODE BEGIN 12 */
  USBD_CDC_HandleTypeDef *hcdc = (USBD_CDC_HandleTypeDef*)hUsbDeviceHS.pClassData;
  if (hcdc->TxState != 0){
    return USBD_BUSY;
  }

  USBD_CDC_SetTxBuffer(&hUsbDeviceHS, Buf, Len);
  result = USBD_CDC_TransmitPacket(&hUsbDeviceHS);
  /* USER CODE END 12 */
  return result;
}

/* USER CODE BEGIN PRIVATE_FUNCTIONS_IMPLEMENTATION */

/**
 * @brief  force clear tx flag by mrCong
 *
 *
 *
 */
void clear_tx_flag()
{
	  USBD_CDC_HandleTypeDef *hcdc = (USBD_CDC_HandleTypeDef*)hUsbDeviceHS.pClassData;
	 hcdc->TxState = 0U;
}


/**
 * @brief  force clear tx flag by mrCong
 *
 *
 *
 */
void ready_to_received_data()
{
	USBD_CDC_SetRxBuffer(&hUsbDeviceHS, UserRxBufferHS);
	USBD_CDC_ReceivePacket(&hUsbDeviceHS); /* sẵn sàng nhận gói tiếp theo*/
}
/* USER CODE END PRIVATE_FUNCTIONS_IMPLEMENTATION */

/**
  * @}
  */

/**
  * @}
  */
