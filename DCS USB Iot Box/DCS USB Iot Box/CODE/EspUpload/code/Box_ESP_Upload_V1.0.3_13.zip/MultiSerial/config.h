/**
   @file 	user_frame.h
   @version     1.01
   @date        2021.11.27
   @author 	Nguyen Thanh Cong
   @contact     thanhcong402@gmail.com
   @contribution

   @description


   @license

*/


#ifndef _config_MultiSerial_
#define _config_MultiSerial_
 
const char *name_up_manager = "/up_manage.sys";
const char *name_disk_info = "/disk.sys";

#define max_file_save 130		//hỗ trợ lưu tối đa 130 file


#define DF_mqtt_modem 1
#define DF_UPFILE_USING_MQTT 1
#define DF_USING_EXT_FLASH 1



/*các biến dùng để debug code*/
#define DF_DEBUG_NOUPLOAD_TO_SERVER 1 /* =1: no upload, =0: normal*/
#define DF_DEBUG_PRINT_EXT_FLASH 0
#define DF_USING_BARCODE 0 /* =0: disbale barcode, =1: normal*/
#define DF_USING_CHECKTIME 1 /* =0: disbale checktime, =1: normal*/

/* 
DF_PRINTER_TYPE
=1: TM-T82II
=2: TM-T82X  
*/
#define DF_PRINTER_TYPE 1 

#endif