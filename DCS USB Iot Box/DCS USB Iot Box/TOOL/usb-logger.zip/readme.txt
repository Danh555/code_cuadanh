Simple USB Logger version 2.0
-----------------------------

OVERVIEW
--------

This  new  unique software product allows capturing traffic 
between device driver and USB device, being transparent for 
this  USB  device.  High  operation  speed  and information 
content  of  USB  Logger  software  allows  to  analyze the 
operation of any USB device.


FEATURES
--------

-  Freeware Software.  From the beginning this software was 
   created  for  inner  company 's needs. But we decided to 
   release it for free for all our customers, so they could 
   use  Simple  USB  Logger  for  their  needs  without any 
   limitations!

-  Simple  Monitoring  Technology.  This  new technology of 
   traffic  capturing  is based on operation of usual Lower 
   Filter.  But  our  unique  feature allows loading driver 
   filter  to  the  stack  of analyzing USB device only. It 
   increases  capturing  speed  and reliable performance in 
   several times.

-  Hardware  and  Virtual  USB  bus  support.  Now  you can 
   monitor  any  USB  device  both real device plugged into 
   Hardware  USB  port and virtual USB device connected via 
   any other software of any vendor!

-  Advanced  URB  parser. Simple USB Logger can display the 
   structures  of  URB  requests  both full and in a simple 
   form (it shows critical data only)!

-  Memory  dump  analyzes.  If  BSOD  occurs  while you are 
   working  with  USB  device,  you  can  get log file from 
   memory.dmp  file.  It allows to see what latest requests 
   USB device processed.

-  Quick  search  features.  Simple  USB Logger can quickly 
   find   packets  finished  with  errors  and  packets  of 
   choosing  new  device  configuration.  To  move  to such 
   packet you just need to press the button on toolbar!

-  USB Redirector is fully compatible with Windows Vista as 
   well as with Windows 64bit.

-  Visual Tracer Submit/Complete.  USB Logger aways follows 
   the sequence of URB packets and shows pairs of submitted 
   and completed requests.

-  Endpoint  filter.  Simple  USB  Logger  allows   setting 
   endpoint filters. It makes it possible to display chosen 
   endpoint packets in log file.

-  Advanced descriptor parser. Simple USB Logger parses all 
   main USB device descritpors and shows them in the window 
   in the structured form.

-  VM ware, Virtual PC compatible.

-  Windows Vista/Windows 7 compatible.

